"""Shared components package."""
