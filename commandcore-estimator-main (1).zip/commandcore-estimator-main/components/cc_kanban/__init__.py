from __future__ import annotations

from components.cc_kanban.cc_kanban import cc_kanban

__all__ = ["cc_kanban"]
