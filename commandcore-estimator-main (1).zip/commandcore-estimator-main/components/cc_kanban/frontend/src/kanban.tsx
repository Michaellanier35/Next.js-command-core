import React, { useEffect, useMemo, useRef, useState } from "react";
import Sortable, { SortableEvent } from "sortablejs";
import { Streamlit } from "streamlit-component-lib";

import type { KanbanColumn, KanbanItem } from "./index";

type KanbanProps = {
  columns: KanbanColumn[];
  items: KanbanItem[];
  selectedId: string | null;
  enableReorder: boolean;
};

type OrderMap = Record<string, KanbanItem[]>;

const buildOrderMap = (columns: KanbanColumn[], items: KanbanItem[]): OrderMap => {
  const map: OrderMap = {};
  columns.forEach((col) => {
    map[col.id] = [];
  });
  items.forEach((item) => {
    if (map[item.columnId]) {
      map[item.columnId].push(item);
    }
  });
  return map;
};

const clampIndex = (value: number | undefined, max: number) => {
  if (value === undefined || Number.isNaN(value)) {
    return max;
  }
  return Math.max(0, Math.min(value, max));
};

const KanbanCard = React.memo(
  ({
    item,
    selected,
    onOpen,
  }: {
    item: KanbanItem;
    selected: boolean;
    onOpen: (id: string) => void;
  }) => {
    const urgency = (item.meta?.urgency as string | undefined) ?? "";
    const subtitle = item.subtitle ?? "";
    const detailLine = (item.meta?.subtitle as string | undefined) ?? "";
    const scope = (item.meta?.scope as string | undefined) ?? "";
    const badges = item.badges ?? [];

    return (
      <div
        className={`cc-card cc-kanban-card${selected ? " cc-kanban-card--selected" : ""}`}
        data-id={item.id}
        data-card="1"
        data-work-order-id={item.id}
        data-status={item.columnId}
        onClick={() => onOpen(item.id)}
      >
        <div className="cc-kanban-card-header">
          <div className="cc-kanban-card-title">{item.title}</div>
          <div className="cc-kanban-card-urgency">{urgency}</div>
        </div>
        <div className="cc-kanban-card-subtitle">{subtitle}</div>
        {detailLine && <div className="cc-kanban-card-detail">{detailLine}</div>}
        {scope && <div className="cc-kanban-card-scope">{scope}</div>}
        {badges.length > 0 && (
          <div className="cc-kanban-card-badges">
            {badges.map((badge) => (
              <span key={badge} className="cc-kanban-badge">
                {badge}
              </span>
            ))}
          </div>
        )}
        <div
          className="cc-drag-handle cc-kanban-card-handle"
          data-drag-handle="1"
          title="Drag to move"
          onPointerDown={(event) => event.stopPropagation()}
          onMouseDown={(event) => event.stopPropagation()}
          onTouchStart={(event) => event.stopPropagation()}
          onClick={(event) => event.stopPropagation()}
        >
          ⠿
        </div>
      </div>
    );
  }
);

const Kanban = ({ columns, items, selectedId, enableReorder }: KanbanProps) => {
  const [orderMap, setOrderMap] = useState<OrderMap>(() => buildOrderMap(columns, items));
  const sortableRefs = useRef<Record<string, Sortable>>({});
  const containerRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const draggingRef = useRef(false);

  const columnIds = useMemo(() => columns.map((col) => col.id), [columns]);

  useEffect(() => {
    setOrderMap(buildOrderMap(columns, items));
  }, [columns, items]);

  useEffect(() => {
    Streamlit.setFrameHeight();
  }, [columns, items, selectedId, orderMap]);

  useEffect(() => {
    const handlePointerDown = (event: PointerEvent | MouseEvent) => {
      const target = event.target as Element | null;
      const path = event.composedPath
        ? event
            .composedPath()
            .slice(0, 5)
            .map((node) => {
              if (node instanceof Element) {
                const className = typeof node.className === "string" ? node.className : "";
                const classSuffix = className.trim() ? `.${className.trim().replace(/\s+/g, ".")}` : "";
                return `${node.tagName.toLowerCase()}${classSuffix}`;
              }
              return String(node);
            })
        : [];
      console.log("cc-kanban capture", {
        type: event.type,
        target: target
          ? {
              tag: target.tagName,
              className: target.className,
              dataset: { ...target.dataset },
            }
          : null,
        isHandle: target?.matches?.("[data-drag-handle]") ?? false,
        closestHandle: Boolean(target?.closest?.("[data-drag-handle]")),
        closestCard: Boolean(target?.closest?.("[data-card]")),
        path,
      });
    };
    document.addEventListener("pointerdown", handlePointerDown, true);
    document.addEventListener("mousedown", handlePointerDown, true);
    return () => {
      document.removeEventListener("pointerdown", handlePointerDown, true);
      document.removeEventListener("mousedown", handlePointerDown, true);
    };
  }, []);

  useEffect(() => {
    columnIds.forEach((columnId) => {
      const container = containerRefs.current[columnId];
      if (!container) {
        return;
      }

      if (sortableRefs.current[columnId]) {
        sortableRefs.current[columnId].destroy();
      }

      sortableRefs.current[columnId] = Sortable.create(container, {
        group: { name: "cc-kanban", pull: true, put: true },
        animation: 150,
        handle: "[data-drag-handle]",
        draggable: "[data-card]",
        ghostClass: "cc-kanban-card--ghost",
        chosenClass: "cc-kanban-card--chosen",
        dragClass: "cc-kanban-card--drag",
        forceFallback: true,
        fallbackOnBody: true,
        fallbackTolerance: 3,
        delayOnTouchOnly: true,
        delay: 120,
        touchStartThreshold: 6,
        disabled: !enableReorder,
        preventOnFilter: false,
        setData: (dataTransfer) => {
          dataTransfer?.setData("text/plain", "");
        },
        onChoose: (evt: SortableEvent) => {
          console.log("Sortable onChoose", {
            column: columnId,
            oldIndex: evt.oldIndex,
            newIndex: evt.newIndex,
          });
        },
        onStart: (evt: SortableEvent) => {
          draggingRef.current = true;
          console.log("Sortable onStart", {
            column: columnId,
            oldIndex: evt.oldIndex,
            newIndex: evt.newIndex,
          });
        },
        onEnd: (evt: SortableEvent) => {
          draggingRef.current = false;
          console.log("Sortable onEnd", {
            column: columnId,
            oldIndex: evt.oldIndex,
            newIndex: evt.newIndex,
          });
          handleDragEnd(evt);
        },
      });
      console.log("Sortable init", {
        column: columnId,
        el: Boolean(container),
        cards: container.querySelectorAll("[data-card]").length,
      });
    });

    return () => {
      Object.values(sortableRefs.current).forEach((sortable) => sortable.destroy());
      sortableRefs.current = {};
    };
  }, [columnIds, enableReorder]);

  const handleDragEnd = (evt: SortableEvent) => {
    const itemId = evt.item?.dataset?.id;
    const workOrderId = evt.item?.dataset?.workOrderId ?? itemId;
    const fromColumn = (evt.from as HTMLElement | null)?.dataset?.columnId;
    const toColumn = (evt.to as HTMLElement | null)?.dataset?.columnId;
    const oldIndex = evt.oldIndex ?? null;
    const newIndex = evt.newIndex ?? null;

    if (!itemId || !fromColumn || !toColumn) {
      return;
    }

    setOrderMap((prev) => {
      const next: OrderMap = { ...prev };
      const fromItems = [...(next[fromColumn] ?? [])];
      const toItems = fromColumn === toColumn ? fromItems : [...(next[toColumn] ?? [])];

      const movingIndex = fromItems.findIndex((item) => item.id === itemId);
      if (movingIndex === -1) {
        return prev;
      }

      const [movingItem] = fromItems.splice(movingIndex, 1);
      const insertionIndex = clampIndex(evt.newIndex ?? undefined, toItems.length);

      const updatedItem =
        fromColumn === toColumn ? movingItem : { ...movingItem, columnId: toColumn };
      toItems.splice(insertionIndex, 0, updatedItem);

      next[fromColumn] = fromItems;
      next[toColumn] = toItems;

      const toOrder = next[toColumn].map((item) => item.id);
      const fromOrder = next[fromColumn].map((item) => item.id);

      Streamlit.setComponentValue({
        type: "MOVE",
        id: workOrderId,
        from: fromColumn,
        to: toColumn,
        toOrder,
        fromOrder,
      });

      return next;
    });
  };

  const handleOpen = (id: string) => {
    if (draggingRef.current) {
      return;
    }
    Streamlit.setComponentValue({
      type: "OPEN",
      id,
    });
  };

  return (
    <div className="cc-kanban-root">
      <div className="cc-kanban-grid">
        {columns.map((column) => {
          const columnItems = orderMap[column.id] ?? [];

          return (
            <div key={column.id} className="cc-kanban-column">
              <div className="cc-kanban-column-header">
                <span>{column.title}</span>
                <span className="cc-kanban-column-count">{column.count}</span>
              </div>
              <div
                className="cc-kanban-list"
                ref={(el) => {
                  containerRefs.current[column.id] = el;
                }}
                data-column-id={column.id}
              >
                {columnItems.map((item) => (
                  <KanbanCard
                    key={item.id}
                    item={item}
                    selected={item.id === selectedId}
                    onOpen={handleOpen}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Kanban;
