import { createAvatarUploadUrl } from "./procedures/create-avatar-upload-url";

export const usersRouter = {
	avatarUploadUrl: createAvatarUploadUrl,
};
