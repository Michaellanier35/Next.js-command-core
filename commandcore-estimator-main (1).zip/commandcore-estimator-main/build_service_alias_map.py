import pandas as pd
import re
from pathlib import Path

SRC = r"C:\CCData\qb\QB_PRICEBOOK_SUMMARY.csv"
OUT = r"C:\CCData\estimator\service_alias_map.csv"

df = pd.read_csv(SRC)
df.columns = [c.strip() for c in df.columns]

items = sorted(set(df["Product/Service full name"].dropna().astype(str)))

def canon(x: str) -> str:
    s = x.lower()
    s = s.replace("–", "-")
    s = re.sub(r"\s+", " ", s).strip()

    if "trip fee" in s and "standard" in s:
        return "TRIP_FEE_STANDARD"
    if "trip fee" in s and "emergency" in s:
        return "TRIP_FEE_EMERGENCY"
    if s.startswith("trip charge"):
        return "TRIP_CHARGE"
    if "nte trip/labor" in s:
        return "NTE_TRIP_LABOR"
    if "nte trip/assessment" in s or "trip/assessment incurred" in s:
        return "TRIP_ASSESSMENT"
    if "nte emergency" in s:
        return "NTE_EMERGENCY_4HR"
    if "labor 1 tech" in s:
        return "LABOR_1_TECH"
    if "labor 2nd tech" in s:
        return "LABOR_2ND_TECH"
    if s == "job labor" or s.startswith("labor:job labor"):
        return "JOB_LABOR"
    if s == "materials" or s.startswith("material:"):
        return "MATERIALS"
    if "disposal" in s:
        return "DISPOSAL"
    if "equipment rental" in s or "equipment usage" in s:
        return "EQUIPMENT"
    if "freight" in s or "shipping" in s:
        return "FREIGHT"

    return "OTHER"

out = pd.DataFrame({
    "raw_item": items,
    "canonical_service": [canon(i) for i in items]
})

Path(OUT).parent.mkdir(parents=True, exist_ok=True)
out.to_csv(OUT, index=False)

print(f"Saved: {OUT} | rows: {len(out)}")
