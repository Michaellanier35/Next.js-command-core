import os
import re
import time
import pandas as pd
import requests
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.environ["SUPABASE_URL"].rstrip("/")
SERVICE_KEY = os.environ["SUPABASE_SERVICE_ROLE_KEY"]
CSV_PATH = "pricebook_norm_quotesafe.csv"

REST_BASE = f"{SUPABASE_URL}/rest/v1"

HEADERS = {
    "apikey": SERVICE_KEY,
    "Authorization": f"Bearer {SERVICE_KEY}",
    "Content-Type": "application/json",
    # This enables upsert behavior when combined with ?on_conflict=...
    "Prefer": "resolution=merge-duplicates,return=representation",
}

def slugify(s: str) -> str:
    s = (s or "").strip().upper()
    s = re.sub(r"[^A-Z0-9]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s[:64] if s else "UNNAMED"

def to_num(x):
    try:
        if pd.isna(x) or x == "":
            return None
        return float(x)
    except Exception:
        return None

def postgrest_upsert(table: str, rows: list[dict], on_conflict: str, chunk_size: int = 500):
    """
    Upsert rows into Supabase via PostgREST.
    Uses: POST /rest/v1/<table>?on_conflict=<cols>
    with Prefer: resolution=merge-duplicates
    """
    if not rows:
        return 0

    url = f"{REST_BASE}/{table}?on_conflict={on_conflict}"
    total = 0

    for i in range(0, len(rows), chunk_size):
        chunk = rows[i:i+chunk_size]
        for attempt in range(5):
            r = requests.post(url, headers=HEADERS, json=chunk, timeout=60)

            # Rate limit / transient errors: backoff and retry
            if r.status_code in (429, 500, 502, 503, 504):
                wait = 1.5 ** attempt
                print(f"Retry {attempt+1}/5 for {table} (HTTP {r.status_code}) sleeping {wait:.1f}s")
                time.sleep(wait)
                continue

            if not r.ok:
                print(f"\n❌ Upsert failed: {table} HTTP {r.status_code}")
                try:
                    print(r.json())
                except Exception:
                    print(r.text)
                raise SystemExit(1)

            total += len(chunk)
            break
        else:
            raise SystemExit(f"❌ Too many retries for {table}")
    return total

def get_all_items():
    """
    Pull pb_items to map item_code -> id.
    """
    url = f"{REST_BASE}/pb_items?select=id,item_code"
    r = requests.get(url, headers={k: HEADERS[k] for k in ("apikey","Authorization")}, timeout=60)
    if not r.ok:
        print(f"❌ Failed to fetch pb_items HTTP {r.status_code}")
        print(r.text)
        raise SystemExit(1)
    data = r.json()
    return {row["item_code"]: row["id"] for row in data}

def main():
    df = pd.read_csv(CSV_PATH)

    # Normalize columns
    df["canonical_service"] = df["canonical_service"].fillna("").astype(str).str.strip()
    df["Customer full name"] = df["Customer full name"].fillna("").astype(str).str.strip()
    df["Product/Service full name"] = df["Product/Service full name"].fillna("").astype(str).str.strip()

    df = df[df["canonical_service"] != ""].copy()

    # -----------------------------------
    # 1) pb_items: one per canonical_service
    # Use global medians/min/max as baseline guidance
    # -----------------------------------
    global_stats = (
        df.groupby("canonical_service", as_index=False)
          .agg(
              base_price=("median_price", "median"),
              min_price=("min_price", "min"),
              max_price=("max_price", "max"),
          )
    )

    items_rows = []
    for _, r in global_stats.iterrows():
        canon = r["canonical_service"]
        item_code = f"SRV-{slugify(canon)}"
        items_rows.append({
            "item_code": item_code,
            "name": canon,
            "item_type": "service",
            "unit": "each",
            "base_price": to_num(r["base_price"]),
            "min_price": to_num(r["min_price"]),
            "max_price": to_num(r["max_price"]),
            "is_active": True,
            "requires_evidence": True,
            "needs_review": False,
        })

    n1 = postgrest_upsert("pb_items", items_rows, on_conflict="item_code", chunk_size=500)
    print(f"✅ pb_items upserted: {n1}")

    # Map item_code -> id (needed for foreign keys)
    code_to_id = get_all_items()
    print(f"✅ pb_items fetched for mapping: {len(code_to_id)}")

    # -----------------------------------
    # 2) pb_item_aliases: QB name -> canonical item
    # -----------------------------------
    alias_rows = df[["canonical_service", "Product/Service full name"]].drop_duplicates()

    aliases_payload = []
    for _, r in alias_rows.iterrows():
        canon = r["canonical_service"]
        alias = r["Product/Service full name"].strip().lower()
        if not alias:
            continue
        item_code = f"SRV-{slugify(canon)}"
        item_id = code_to_id.get(item_code)
        if not item_id:
            continue
        aliases_payload.append({
            "item_id": item_id,
            "alias": alias,
            "source": "quickbooks",
            "confidence": 0.90,
        })

    n2 = postgrest_upsert("pb_item_aliases", aliases_payload, on_conflict="alias", chunk_size=1000)
    print(f"✅ pb_item_aliases upserted: {n2}")

    # -----------------------------------
    # 3) pb_client_overrides: customer + item -> median as override_price
    # -----------------------------------
    override_rows = (
        df.groupby(["Customer full name", "canonical_service"], as_index=False)
          .agg(
              cnt=("count", "sum"),
              median=("median_price", "median"),
              avg=("avg_price", "mean"),
              minp=("min_price", "min"),
              maxp=("max_price", "max"),
              avg_qty=("avg_qty", "mean"),
          )
    )

    overrides_payload = []
    for _, r in override_rows.iterrows():
        client = r["Customer full name"].strip()
        canon = r["canonical_service"].strip()
        if not client or not canon:
            continue

        item_code = f"SRV-{slugify(canon)}"
        item_id = code_to_id.get(item_code)
        if not item_id:
            continue

        notes = (
            f"QB import: jobs={int(r['cnt']) if pd.notna(r['cnt']) else 'n/a'}, "
            f"median={to_num(r['median'])}, avg={to_num(r['avg'])}, "
            f"min={to_num(r['minp'])}, max={to_num(r['maxp'])}, avg_qty={to_num(r['avg_qty'])}"
        )

        overrides_payload.append({
            "client_name": client,
            "item_id": item_id,
            "override_price": to_num(r["median"]),  # stable default
            "notes": notes,
            "is_active": True,
        })

    n3 = postgrest_upsert("pb_client_overrides", overrides_payload, on_conflict="client_name,item_id", chunk_size=500)
    print(f"✅ pb_client_overrides upserted: {n3}")

    print("\n✅✅ Import complete.")

if __name__ == "__main__":
    main()
