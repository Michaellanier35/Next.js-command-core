import argparse
import csv
import os
import re
from pathlib import Path
from urllib.parse import quote as urlquote

import pandas as pd
import requests
from dotenv import load_dotenv

# =========================================================
# Load env (Supabase keys live in .env)
# =========================================================
load_dotenv()
SUPABASE_URL = (os.getenv("SUPABASE_URL") or "").rstrip("/")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY") or ""  # sb_publishable_...

def supabase_ready() -> bool:
    return bool(SUPABASE_URL and SUPABASE_ANON_KEY)

def supabase_headers():
    return {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
    }

SUPABASE_REST = f"{SUPABASE_URL}/rest/v1" if SUPABASE_URL else ""

# =========================================================
# Non-material scope → service triggers (kept hard-coded)
# =========================================================
SERVICE_HINTS = [
    (r"\bemergency\b|\bafter\s*hours\b|\b4\s*hr\b|\b4hr\b", "NTE_EMERGENCY_4HR"),
    (r"\btrip\b|\bassessment\b", "TRIP_ASSESSMENT"),
    (r"\blabor\b|\btech\b|\bhour\b|\brepair\b|\bservice\b|\binstall\b|\breplace\b|\breplace\b", "LABOR_1_TECH"),
    (r"\bdisposal\b|\bha(u)?l\b", "DISPOSAL"),
    (r"\bequipment\b|\blift\b|\bscissor\b|\bfork\b|\bdehumidifier\b|\bdryer\b|\brental\b", "EQUIPMENT"),
    (r"\bfreight\b|\bshipping\b|\bdelivery\b", "FREIGHT"),
]

# Exclusions to keep evidence “materials only”
EXCLUDE_EVIDENCE_RULES = [
    r"\btrip\b",
    r"\blabor\b",
    r"\bassessment\b",
    r"\bbase\s*rate\b",
    r"\bservice\s*call\b",
    r"\bdispatch\b",
    r"\btravel\b",
    r"\bdiagnostic\b",
    r"\bnte\b",
]

# =========================================================
# Materials map loader (THIS IS THE NEW SOURCE OF TRUTH)
# =========================================================
def load_materials_map_csv(path: str):
    """
    Reads materials_bucket_map_v1.csv and returns:
      - material_svcs: set[str] (bucket names)
      - bucket_patterns: dict[bucket] -> list[regex patterns]
    Uses only rows where:
      active == TRUE
      policy == map
    """
    df = pd.read_csv(path)

    df.columns = [c.strip() for c in df.columns]
    required = {"suggested_bucket", "suggested_regex", "active", "policy"}
    missing = required - set(df.columns)
    if missing:
        raise SystemExit(f"Materials map missing required columns: {sorted(missing)}")

    df["active_norm"] = df["active"].astype(str).str.strip().str.upper()
    df["policy_norm"] = df["policy"].astype(str).str.strip().str.lower()
    df["bucket_norm"] = df["suggested_bucket"].astype(str).str.strip().str.upper()
    df["regex_norm"] = df["suggested_regex"].astype(str).str.strip()

    df = df[(df["active_norm"] == "TRUE") & (df["policy_norm"] == "map")].copy()
    df = df[df["bucket_norm"] != ""]
    df = df[df["regex_norm"] != ""]

    bucket_patterns: dict[str, list[str]] = {}
    for _, r in df.iterrows():
        b = r["bucket_norm"]
        pat = r["regex_norm"]
        bucket_patterns.setdefault(b, []).append(pat)

    material_svcs = set(bucket_patterns.keys())
    return material_svcs, bucket_patterns

# =========================================================
# QB sales detail loader (fixed-position)
# =========================================================
def load_qb_sales_detail_rows(path: str) -> list[dict]:
    """
    Parses QuickBooks 'Sales by Customer Detail' export rows by position.
    Positions (based on your file):
      1 = Date
      2 = Txn Type
      3 = Num (Invoice #)
      4 = Product/Service
      5 = Description/Memo
      8 = Amount
      14 = Customer
    """
    rows: list[dict] = []
    with open(path, newline="", errors="ignore") as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) < 15:
                continue
            if (row[2] or "").strip() != "Invoice":
                continue

            date = (row[1] or "").strip()
            invoice_num = (row[3] or "").strip()
            item = (row[4] or "").strip()
            desc = (row[5] or "").strip()
            amount = (row[8] or "").strip()
            customer = (row[14] or "").strip()

            if not date or not invoice_num:
                continue

            text = f"{item} {desc}".lower()

            if any(re.search(p, text, re.IGNORECASE) for p in EXCLUDE_EVIDENCE_RULES):
                continue

            rows.append(
                {
                    "date": date,
                    "invoice_num": invoice_num,
                    "item": item,
                    "desc": desc,
                    "amount": amount,
                    "customer": customer,
                    "text": text,
                }
            )

    return rows

def row_matches_bucket(row: dict, bucket: str, bucket_patterns: dict[str, list[str]]) -> bool:
    pats = bucket_patterns.get(bucket, [])
    if not pats:
        return False
    t = row.get("text", "")
    return any(re.search(p, t, re.IGNORECASE) for p in pats)

def print_materials_evidence_customer_only(
    qb_rows: list[dict],
    material_buckets: list[str],
    customer: str,
    min_examples: int,
    top_n: int,
    bucket_patterns: dict[str, list[str]],
):
    """
    Customer-specific evidence ONLY (no global fallback).
    If insufficient customer evidence, bucket prints as skipped.
    """
    print("\n--- MATERIALS EVIDENCE (Invoice Examples) ---")
    print("Materials buckets included:", ", ".join(material_buckets) if material_buckets else "(none)")

    for bucket in material_buckets:
        cust_hits = [
            r for r in qb_rows
            if r.get("customer") == customer and row_matches_bucket(r, bucket, bucket_patterns)
        ]

        if len(cust_hits) < min_examples:
            print(f"\n{bucket} (no customer-specific evidence — skipped)")
            continue

        print(f"\n{bucket} (customer-specific) examples_found={len(cust_hits)} (min_required={min_examples})")

        for r in cust_hits[:top_n]:
            raw_amt = r.get("amount", "")
            try:
                amt = f"${float(raw_amt):,.2f}"
            except Exception:
                amt = raw_amt

            print(f"Invoice #{r['invoice_num']} | {r['date']} | {r['item']} | {amt}")

# =========================================================
# Estimator helpers (pricebook)
# =========================================================
def is_path_like(s: str) -> bool:
    if not s:
        return False
    s = s.strip()
    return (":\\" in s) or s.startswith("\\\\") or s.endswith(".csv") or s.endswith(".txt")

# ---------- CSV PRICEBOOK (legacy fallback) ----------
def load_pricebook_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    required = {"Customer full name", "canonical_service", "count", "median_price", "min_price", "max_price"}
    missing = required - set(df.columns)
    if missing:
        raise SystemExit(f"Pricebook missing required columns: {sorted(missing)}")
    df["cust_norm"] = df["Customer full name"].astype(str).str.lower().str.strip()
    df["svc_norm"] = df["canonical_service"].astype(str).str.upper().str.strip()
    return df

def best_row_csv(df: pd.DataFrame, cust_norm: str, svc: str):
    sub = df[(df["cust_norm"] == cust_norm) & (df["svc_norm"] == svc)].copy()
    if sub.empty:
        sub = df[df["svc_norm"] == svc].copy()
    if sub.empty:
        return None
    sub["count"] = pd.to_numeric(sub["count"], errors="coerce").fillna(0)
    return sub.sort_values("count", ascending=False).iloc[0]

# ---------- SUPABASE PRICEBOOK (primary) ----------
def _parse_jobs_from_notes(notes: str | None) -> int:
    if not notes:
        return 0
    m = re.search(r"\bjobs\s*=\s*(\d+)", str(notes), re.IGNORECASE)
    if m:
        try:
            return int(m.group(1))
        except Exception:
            return 0
    return 0

def fetch_overrides_for_customer(customer_name: str) -> dict[str, dict]:
    """
    Returns dict keyed by svc_norm (pb_items.name upper)
    Value contains: median_price, min_price, max_price, count, source_customer
    """
    if not supabase_ready():
        return {}

    # Embed pb_items fields through FK (item_id -> pb_items)
    # PostgREST embedding syntax: pb_items(...)
    sel = "select=override_price,notes,client_name,pb_items(name,min_price,max_price,base_price)"
    url = (
        f"{SUPABASE_REST}/pb_client_overrides?"
        f"{sel}&is_active=eq.true&client_name=eq.{urlquote(customer_name)}&limit=10000"
    )

    r = requests.get(url, headers=supabase_headers(), timeout=30)
    r.raise_for_status()
    rows = r.json()

    out: dict[str, dict] = {}
    for row in rows:
        pb = row.get("pb_items") or {}
        name = (pb.get("name") or "").strip()
        if not name:
            continue

        svc_norm = name.upper().strip()
        median = row.get("override_price")
        base = pb.get("base_price")
        minv = pb.get("min_price")
        maxv = pb.get("max_price")

        # Fallback logic if min/max missing
        # Prefer median, then base, then min/max fallback to same value.
        chosen = median if median is not None else base
        if chosen is None:
            continue

        if minv is None:
            minv = chosen
        if maxv is None:
            maxv = chosen

        out[svc_norm] = {
            "Customer full name": row.get("client_name") or customer_name,
            "canonical_service": svc_norm,
            "count": _parse_jobs_from_notes(row.get("notes")),
            "median_price": float(chosen),
            "min_price": float(minv),
            "max_price": float(maxv),
        }
    return out

def fetch_pb_items_by_names(names: list[str]) -> dict[str, dict]:
    """
    Fetches pb_items rows by name and returns dict keyed by svc_norm.
    Used as fallback if a service isn't present in customer overrides.
    """
    if not supabase_ready() or not names:
        return {}

    # PostgREST in syntax: name=in.(A,B,C)
    # Need to URL-encode each name safely.
    encoded = ",".join([urlquote(n) for n in names])
    sel = "select=name,base_price,min_price,max_price"
    url = f"{SUPABASE_REST}/pb_items?{sel}&is_active=eq.true&name=in.({encoded})&limit=10000"

    r = requests.get(url, headers=supabase_headers(), timeout=30)
    r.raise_for_status()
    rows = r.json()

    out: dict[str, dict] = {}
    for row in rows:
        name = (row.get("name") or "").strip()
        if not name:
            continue
        svc_norm = name.upper().strip()
        base = row.get("base_price")
        minv = row.get("min_price")
        maxv = row.get("max_price")

        chosen = base
        if chosen is None and minv is not None:
            chosen = minv
        if chosen is None and maxv is not None:
            chosen = maxv
        if chosen is None:
            continue

        if minv is None:
            minv = chosen
        if maxv is None:
            maxv = chosen

        out[svc_norm] = {
            "Customer full name": "(pb_items)",
            "canonical_service": svc_norm,
            "count": 0,
            "median_price": float(chosen),
            "min_price": float(minv),
            "max_price": float(maxv),
        }
    return out

def scale_labor(median: float, minv: float, maxv: float, techs: int, hours: float):
    techs = max(1, int(techs))
    hours = max(0.25, float(hours))
    mult = techs * hours
    return median * mult, minv * mult, maxv * mult

def pick_services(scope: str, include_materials: bool, material_svcs: set[str], bucket_patterns: dict[str, list[str]]) -> list[str]:
    """
    - Keeps existing non-material SERVICE_HINTS
    - Adds materials buckets by matching scope against materials map regex
    """
    s = (scope or "").lower().strip()
    hits: list[str] = []

    for pat, svc in SERVICE_HINTS:
        if re.search(pat, s):
            hits.append(svc)

    if include_materials:
        for bucket in sorted(material_svcs):
            pats = bucket_patterns.get(bucket, [])
            if any(re.search(p, s, re.IGNORECASE) for p in pats):
                hits.append(bucket)

    if "TRIP_ASSESSMENT" not in hits:
        hits.insert(0, "TRIP_ASSESSMENT")
    if "LABOR_1_TECH" not in hits:
        hits.append("LABOR_1_TECH")

    out: list[str] = []
    for x in hits:
        if x not in out:
            out.append(x)
    return out

# =========================================================
# Main
# =========================================================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--customer", required=True)
    ap.add_argument("--scope", required=True)

    ap.add_argument("--techs", type=int, default=1, help="Number of techs")
    ap.add_argument("--hours", type=float, default=1.0, help="Hours per tech (first hour = 1.0)")

    ap.add_argument("--materials", action="store_true", help="Include materials lines (off by default)")
    ap.add_argument("--materials_allowance", type=float, default=0.0, help="If >0, force all materials line(s) to this allowance")

    ap.add_argument("--materials_top_n", type=int, default=3, help="How many evidence lines to show per materials bucket")
    ap.add_argument("--materials_min_examples", type=int, default=3, help="Min customer-specific examples required to show evidence")

    ap.add_argument("--qb_sales_detail", default="", help="QB Sales by Customer Detail CSV path (optional)")

    # Legacy CSV input still accepted for fallback + compatibility
    ap.add_argument("--pricebook", default="pricebook_norm_quotesafe.csv", help="Pricebook CSV file (legacy fallback)")
    ap.add_argument("--materials_map", default="materials_bucket_map_v1.csv", help="Materials bucket map CSV (v1)")

    args = ap.parse_args()
    base_dir = Path(__file__).resolve().parent

    # Resolve materials map path
    mm_path = args.materials_map
    if not is_path_like(mm_path):
        mm_path = str((base_dir / mm_path).resolve())
    if not Path(mm_path).exists():
        raise SystemExit(f"Materials map not found: {mm_path}")

    material_svcs, bucket_patterns = load_materials_map_csv(mm_path)

    cust = args.customer.strip()
    cust_norm = cust.lower().strip()

    services = pick_services(args.scope, args.materials, material_svcs, bucket_patterns)

    # Evidence printing (materials only; customer-specific only)
    if args.materials and args.qb_sales_detail:
        try:
            qb_path = args.qb_sales_detail
            if not is_path_like(qb_path):
                qb_path = str((base_dir / qb_path).resolve())
            if Path(qb_path).exists():
                qb_rows = load_qb_sales_detail_rows(qb_path)
                material_buckets = [svc for svc in services if svc in material_svcs]
                print_materials_evidence_customer_only(
                    qb_rows=qb_rows,
                    material_buckets=material_buckets,
                    customer=cust,
                    min_examples=args.materials_min_examples,
                    top_n=args.materials_top_n,
                    bucket_patterns=bucket_patterns,
                )
        except Exception as e:
            print("\n--- MATERIALS EVIDENCE (Invoice Examples) ---")
            print(f"(evidence skipped due to error: {e})")

    # =========================================================
    # PRICEBOOK SOURCE: Supabase-first, CSV fallback
    # =========================================================
    pricebook_mode = "supabase" if supabase_ready() else "csv"

    overrides = {}
    pb_items_fallback = {}

    if pricebook_mode == "supabase":
        try:
            overrides = fetch_overrides_for_customer(cust)
            # fallback pb_items for missing services
            missing = [svc for svc in services if svc.upper().strip() not in overrides]
            pb_items_fallback = fetch_pb_items_by_names(missing)
        except Exception:
            # If Supabase fails for any reason, drop to CSV
            pricebook_mode = "csv"
            overrides = {}
            pb_items_fallback = {}

    df_csv = None
    if pricebook_mode == "csv":
        pb_path = args.pricebook
        if not is_path_like(pb_path):
            pb_path = str((base_dir / pb_path).resolve())
        if not Path(pb_path).exists():
            raise SystemExit(f"Pricebook not found: {pb_path}")
        df_csv = load_pricebook_csv(pb_path)

    # Build pricing rows
    rows: list[dict] = []
    for svc in services:
        svc_norm = svc.upper().strip()

        r = None

        if pricebook_mode == "supabase":
            # Customer override first
            if svc_norm in overrides:
                r = overrides[svc_norm]
            # Then pb_items fallback
            elif svc_norm in pb_items_fallback:
                r = pb_items_fallback[svc_norm]
            else:
                r = None

        if pricebook_mode == "csv" and df_csv is not None:
            r_csv = best_row_csv(df_csv, cust_norm, svc_norm)
            if r_csv is not None:
                r = {
                    "Customer full name": r_csv["Customer full name"],
                    "canonical_service": svc_norm,
                    "count": int(float(r_csv["count"])) if pd.notna(r_csv["count"]) else 0,
                    "median_price": float(r_csv["median_price"]),
                    "min_price": float(r_csv["min_price"]) if pd.notna(r_csv["min_price"]) else float(r_csv["median_price"]),
                    "max_price": float(r_csv["max_price"]) if pd.notna(r_csv["max_price"]) else float(r_csv["median_price"]),
                }

        if r is None:
            continue

        median = float(r["median_price"])
        minv = float(r["min_price"]) if r.get("min_price") is not None else median
        maxv = float(r["max_price"]) if r.get("max_price") is not None else median

        if svc_norm == "LABOR_1_TECH":
            median, minv, maxv = scale_labor(median, minv, maxv, args.techs, args.hours)

        if (svc_norm in material_svcs) and args.materials and args.materials_allowance and args.materials_allowance > 0:
            median = minv = maxv = float(args.materials_allowance)

        rows.append(
            {
                "service": svc_norm,
                "median": median,
                "min": minv,
                "max": maxv,
                "count": int(r.get("count") or 0),
                "source_customer": r.get("Customer full name") or "(unknown)",
            }
        )

    if not rows:
        print("No pricing matches found. Check customer spelling or mappings.")
        return

    trip_row = next((x for x in rows if x["service"] == "TRIP_ASSESSMENT"), None)
    labor_row = next((x for x in rows if x["service"] == "LABOR_1_TECH"), None)

    print("\n--- QUOTE SUGGESTION (Customer-specific) ---")
    print("Customer:", cust)
    print("Scope:", args.scope)
    print(f"Techs: {args.techs} | Hours per tech: {args.hours}")
    print(f"Pricebook mode: {pricebook_mode}")
    print("")

    print("--- INITIAL NTE (Trip + First Hour) ---")
    if trip_row and labor_row:
        init_med = trip_row["median"] + labor_row["median"]
        init_min = trip_row["min"] + labor_row["min"]
        init_max = trip_row["max"] + labor_row["max"]

        for rr in [trip_row, labor_row]:
            print(
                f"{rr['service']}: ${rr['median']:.2f}  (range ${rr['min']:.2f}-${rr['max']:.2f})  "
                f"examples={rr['count']}  source={rr['source_customer']}"
            )
        print(f"INITIAL NTE (median): ${init_med:.2f}")
        print(f"INITIAL NTE RANGE: ${init_min:.2f} - ${init_max:.2f}")
    else:
        print("Not enough data to build Initial NTE (missing Trip or Labor).")
    print("--------------------------------------\n")

    for rr in rows:
        print(
            f"{rr['service']}: ${rr['median']:.2f}  (range ${rr['min']:.2f}-${rr['max']:.2f})  "
            f"examples={rr['count']}  source={rr['source_customer']}"
        )

    total_med = sum(rr["median"] for rr in rows)
    total_min = sum(rr["min"] for rr in rows)
    total_max = sum(rr["max"] for rr in rows)

    print("")
    print(f"TOTAL (median): ${total_med:.2f}")
    print(f"TOTAL RANGE: ${total_min:.2f} - ${total_max:.2f}")
    print("------------------------------------------\n")

if __name__ == "__main__":
    main()
