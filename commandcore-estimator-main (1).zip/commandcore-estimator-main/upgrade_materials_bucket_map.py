import argparse
import os
import re
import pandas as pd


def norm(s: str) -> str:
    return (s or "").strip().lower()


def is_deleted(item_norm: str) -> bool:
    return "(deleted)" in norm(item_norm)


def looks_like_diverter(item_norm: str) -> bool:
    s = norm(item_norm)
    return ("diverter" in s) or ("water diverter" in s)


def should_be_materials_map(item_norm: str) -> bool:
    """
    What we consider 'real materials' for the canonical materials dictionary.
    """
    s = norm(item_norm)

    # Always treat deleted items as evidence-only (keeps the dictionary clean)
    if is_deleted(s):
        return False

    # Strong signals: QB item prefixes
    if s.startswith("material:"):
        return True
    if s.startswith("door parts:"):
        return True

    # Named, non-prefixed materials you may want to keep
    keep_named = {
        "glass",
        "bollard",
        "heavy duty door sweep",
        "heavy duty continuous hinge",
    }
    if s in keep_named:
        return True

    # If it looks like a diverter but isn't prefixed, we still treat it as evidence-only by default
    # (you can flip later if desired)
    if looks_like_diverter(s):
        return False

    return False


def upgrade(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["item_norm"] = df["item_norm"].astype(str).str.strip().str.lower()

    # Ensure required columns exist
    required = {"suggested_bucket", "item_norm", "example_name", "count", "customers_count", "suggested_regex"}
    missing = required - set(df.columns)
    if missing:
        raise SystemExit(f"Missing required columns in input CSV: {sorted(missing)}")

    # Add columns if missing
    if "active" not in df.columns:
        df["active"] = True
    if "policy" not in df.columns:
        df["policy"] = "map"
    if "notes" not in df.columns:
        df["notes"] = ""

    # Default policy based on item type
    for i, row in df.iterrows():
        item_norm = row["item_norm"]

        # Fix diverter-ish items that got mapped to misc
        if looks_like_diverter(item_norm) and row["suggested_bucket"] == "MATERIALS_MISC":
            df.at[i, "suggested_bucket"] = "MATERIALS_WATER_DIVERTER"
            df.at[i, "notes"] = (df.at[i, "notes"] + " auto: diverter->MATERIALS_WATER_DIVERTER;").strip()

        # Deleted items -> evidence_only
        if is_deleted(item_norm):
            df.at[i, "active"] = False
            df.at[i, "policy"] = "evidence_only"
            df.at[i, "notes"] = (df.at[i, "notes"] + " auto: deleted->evidence_only;").strip()
            continue

        # Decide if this should be part of canonical materials map
        if should_be_materials_map(item_norm):
            df.at[i, "active"] = True
            df.at[i, "policy"] = "map"
        else:
            # Not clean enough to become a canonical material item
            df.at[i, "active"] = False
            df.at[i, "policy"] = "evidence_only"
            if not df.at[i, "notes"]:
                df.at[i, "notes"] = "auto: not canonical material item;"

    # Sort nicely
    df = df.sort_values(["policy", "active", "suggested_bucket", "count"], ascending=[True, False, True, False])

    # Normalize boolean output to TRUE/FALSE for Excel friendliness
    df["active"] = df["active"].apply(lambda x: "TRUE" if bool(x) else "FALSE")

    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_map", default="materials_bucket_map.csv", help="Input mapping CSV")
    ap.add_argument("--out_map", default="materials_bucket_map_v1.csv", help="Output mapping CSV")
    args = ap.parse_args()

    df = pd.read_csv(args.in_map)
    out = upgrade(df)

    out.to_csv(args.out_map, index=False)
    print(f"Wrote: {os.path.abspath(args.out_map)}")
    print(f"Rows: {len(out)}")
    print("Policy counts:")
    print(out["policy"].value_counts().to_string())


if __name__ == "__main__":
    main()
