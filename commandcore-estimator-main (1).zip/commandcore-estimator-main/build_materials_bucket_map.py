import argparse
import re
import os
import pandas as pd

# What we consider "materials-like" item_norms
MATERIAL_PREFIXES = (
    "material:",
    "door parts:",
)

# Things we explicitly exclude from the materials map
EXCLUDE_ITEM_NORMS = {
    "equipment rental/usage",
    "equipment usage and transport fee",
    "disposal:disposal",
    "job site cleanup",
    "freight / shipping",
    "services",
    "emergency rate:1 tech emergency rate",
    "change order",
    "processing",
}

# Quick heuristic bucketing (first-pass suggestions)
def suggest_bucket(item_norm: str) -> str:
    s = item_norm.lower().strip()

    # Core “Material:” categories
    if s.startswith("material:"):
        if "water diverter" in s or "diverter" in s:
            return "MATERIALS_WATER_DIVERTER"
        if "paint" in s:
            return "MATERIALS_PAINT"
        if "drywall" in s:
            return "MATERIALS_DRYWALL"
        if "ceiling tile" in s:
            return "MATERIALS_CEILING_TILE"
        if "brick" in s:
            return "MATERIALS_BRICK"
        if "cove base" in s:
            return "MATERIALS_COVE_BASE"
        if "floor covering" in s or "lvp" in s:
            return "MATERIALS_FLOORING"
        return "MATERIALS_MISC"

    # Door parts categories
    if s.startswith("door parts:"):
        if "flush bolt" in s or "flushbolt" in s:
            return "MATERIALS_FLUSHBOLT"
        if "continuous hinge" in s or "piano hinge" in s or "hinge" in s:
            return "MATERIALS_CONTINUOUS_HINGE"
        if "sweep" in s:
            return "MATERIALS_DOOR_SWEEP"
        if "lever" in s or "lock" in s or "lockset" in s:
            return "MATERIALS_LEVERSET"
        if "threshold" in s:
            return "MATERIALS_THRESHOLD"
        return "MATERIALS_DOOR_PARTS_MISC"

    # Named items not under prefixes
    if "continuous hinge" in s or "piano hinge" in s:
        return "MATERIALS_CONTINUOUS_HINGE"
    if "door sweep" in s:
        return "MATERIALS_DOOR_SWEEP"
    if s == "glass":
        return "MATERIALS_GLASS"
    if s == "bollard":
        return "MATERIALS_BOLLARD"

    # Fallback
    return "MATERIALS_MISC"


def build_regex(item_norm: str) -> str:
    """
    First-pass regex: escape the normalized item string but loosen spaces.
    You will refine these later.
    """
    s = item_norm.lower().strip()
    s = re.escape(s)
    s = s.replace("\\ ", r"\s+")
    return s


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--catalog", default="materials_catalog.csv", help="Path to materials_catalog.csv")
    ap.add_argument("--out", default="materials_bucket_map.csv", help="Output mapping CSV")
    ap.add_argument("--min_count", type=int, default=3, help="Only include item_norms with count >= this")
    args = ap.parse_args()

    df = pd.read_csv(args.catalog)

    # Basic filters
    df["item_norm"] = df["item_norm"].astype(str).str.strip().str.lower()
    df = df[df["count"] >= args.min_count].copy()

    # Exclude obvious non-material categories
    df = df[~df["item_norm"].isin(EXCLUDE_ITEM_NORMS)].copy()

    # Keep only materials-like prefixes OR known named materials
    keep_named = {"glass", "bollard", "heavy duty door sweep", "heavy duty continuous hinge"}
    df = df[
        df["item_norm"].str.startswith(MATERIAL_PREFIXES)
        | df["item_norm"].isin(keep_named)
        | df["item_norm"].str.contains("water diverter", na=False)
    ].copy()

    # Add suggested bucket + regex
    df["suggested_bucket"] = df["item_norm"].apply(suggest_bucket)
    df["suggested_regex"] = df["item_norm"].apply(build_regex)

    # Helpful columns for review
    out = df[
        [
            "suggested_bucket",
            "item_norm",
            "example_name",
            "count",
            "customers_count",
            "amount_min",
            "amount_median",
            "amount_max",
            "first_seen",
            "last_seen",
            "suggested_regex",
        ]
    ].copy()

    out = out.sort_values(["suggested_bucket", "count"], ascending=[True, False])

    out.to_csv(args.out, index=False)
    print(f"Wrote: {os.path.abspath(args.out)}")
    print(f"Rows: {len(out)}")


if __name__ == "__main__":
    main()
