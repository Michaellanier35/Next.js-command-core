import io
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, List, Tuple, Any
from urllib.parse import quote as urlquote

import pandas as pd
import requests
import streamlit as st
from dotenv import load_dotenv
from openai import OpenAI
from pypdf import PdfReader

ENABLE_CUSTOM_KANBAN = (os.getenv("ENABLE_CUSTOM_KANBAN") or "true").lower() in {"1", "true", "yes"}
CUSTOM_KANBAN_AVAILABLE = False
CUSTOM_KANBAN_ERR = ""
try:
    from components.cc_kanban import cc_kanban as cc_kanban_component

    CUSTOM_KANBAN_AVAILABLE = True
except Exception as e:
    cc_kanban_component = None
    CUSTOM_KANBAN_ERR = repr(e)

# =========================
# Env + clients
# =========================
load_dotenv()

SUPABASE_URL = (os.getenv("SUPABASE_URL") or "").rstrip("/")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY") or ""
SUPABASE_SERVICE_ROLE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY") or ""
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD") or ""
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY") or ""

SUPABASE_REST = f"{SUPABASE_URL}/rest/v1" if SUPABASE_URL else ""
oa_client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

# =========================
# Paths
# =========================
BASE_DIR = Path(__file__).resolve().parent
QUOTE_SCRIPT = BASE_DIR / "quote_bundle.py"

PRICEBOOK_QUOTESAFE = BASE_DIR / "pricebook_norm_quotesafe.csv"
PRICEBOOK_STANDARD = BASE_DIR / "pricebook_norm.csv"
DEFAULT_PRICEBOOK = str(PRICEBOOK_QUOTESAFE if PRICEBOOK_QUOTESAFE.exists() else PRICEBOOK_STANDARD)
DEFAULT_QB_SALES_DETAIL = BASE_DIR / "qb_sales_raw.csv"

DATA_DIR = BASE_DIR / "data"
HISTORY_PATH = DATA_DIR / "quote_history.jsonl"

# =========================
# Streamlit config + CSS
# =========================
st.set_page_config(page_title="CommandCore", layout="wide")

with st.expander("Diagnostics", expanded=True):
    diag_version = "DIAG_VERSION: 2026-01-19a"
    frontend_dir = BASE_DIR / "components" / "cc_kanban" / "frontend"
    build_dir = frontend_dir / "build"
    index_html = build_dir / "index.html"
    st.write(diag_version)
    st.write("cwd", os.getcwd())
    st.write("BASE_DIR", str(BASE_DIR))
    st.write("frontend_dir", str(frontend_dir))
    st.write("build_dir", str(build_dir))
    st.write("index_html", str(index_html))
    st.write("BASE_DIR exists", BASE_DIR.exists())
    st.write("frontend_dir exists", frontend_dir.exists())
    st.write("build_dir exists", build_dir.exists())
    st.write("index_html exists", index_html.exists())
    if frontend_dir.exists():
        st.write(
            "components/cc_kanban/frontend/ contents",
            sorted(p.name for p in frontend_dir.iterdir()),
        )
    else:
        st.write("components/cc_kanban/frontend/ contents", "MISSING")
    if build_dir.exists():
        st.write(
            "components/cc_kanban/frontend/build/ contents",
            sorted(p.name for p in build_dir.iterdir()),
        )
    else:
        st.write("components/cc_kanban/frontend/build/ contents", "MISSING")

st.markdown(
    """
<style>
.block-container { padding-top: 1.2rem; padding-bottom: 2.6rem; max-width: 1800px; }
h1, h2, h3 { letter-spacing: -0.02em; }
.stAppHeader { background: transparent; }
.stAppHeader::before { background: transparent; }

.cc-card {
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.10);
  border-radius: 16px;
  padding: 18px 18px 14px 18px;
  margin-bottom: 16px;
  box-shadow: 0 10px 26px rgba(0,0,0,0.08);
}
.cc-muted { opacity: 0.75; font-size: 0.92rem; }
.cc-subtle { color: rgba(255,255,255,0.70); font-size: 0.9rem; }
.cc-sticky { position: sticky; top: 1.2rem; }
.cc-pill { background: rgba(255,255,255,0.08); border-radius: 10px; padding: 0.35rem 0.6rem; font-size: 0.86rem; display:inline-block; }
.cc-pill-danger { background: rgba(255,71,87,0.18); color: #ff6b78; border: 1px solid rgba(255,71,87,0.35); }
.cc-pill-warn { background: rgba(255,168,0,0.18); color: #ffb347; border: 1px solid rgba(255,168,0,0.35); }
.cc-pill-ok { background: rgba(40,199,111,0.18); color: #37d887; border: 1px solid rgba(40,199,111,0.35); }

.cc-badge {
  display: inline-flex; align-items: center; gap: 0.35rem;
  padding: 0.18rem 0.6rem; border-radius: 999px;
  font-size: 0.78rem; font-weight: 700; letter-spacing: 0.01em;
}
.cc-badge-emergency { background: rgba(255,71,87,0.15); color: #ff6b78; border: 1px solid rgba(255,71,87,0.35); }
.cc-badge-med { background: rgba(255,168,0,0.15); color: #ffb347; border: 1px solid rgba(255,168,0,0.35); }
.cc-badge-low { background: rgba(40,199,111,0.15); color: #37d887; border: 1px solid rgba(40,199,111,0.35); }

div[data-testid="stMetricValue"] { font-size: 1.35rem; }
div[data-testid="stMetricLabel"] { font-size: 0.86rem; opacity: 0.75; }
div.stButton > button { border-radius: 10px; padding: 0.48rem 0.9rem; font-weight: 700; }

.kanban-col {
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 16px;
  padding: 10px 10px 6px 10px;
  min-height: 240px;
}

.kanban-title {
  font-size: 0.95rem;
  font-weight: 800;
  opacity: 0.9;
  margin-bottom: 8px;
}

.wo-card {
  background: rgba(0,0,0,0.20);
  border: 1px solid rgba(255,255,255,0.10);
  border-radius: 14px;
  padding: 10px 10px 8px 10px;
  margin-bottom: 10px;
}

.wo-topline { display:flex; justify-content:space-between; align-items:center; gap:10px; }
.wo-meta { display:flex; flex-wrap:wrap; gap:6px; margin: 6px 0 4px 0; }
.wo-wo { font-weight: 900; font-size: 0.86rem; }
.wo-client { font-weight: 700; font-size: 0.88rem; margin-top: 4px; }
.wo-sub { opacity:0.8; font-size:0.82rem; margin-top:2px; }
.wo-scope { opacity:0.85; font-size:0.82rem; margin-top:6px; }
.small { font-size: 0.88rem; opacity: 0.8; }
</style>
""",
    unsafe_allow_html=True,
)

# =========================
# Header
# =========================
hL, hR = st.columns([0.14, 0.86])
with hL:
    logo_path = BASE_DIR / "assets" / "LOGO.png"
    if logo_path.exists():
        st.image(str(logo_path), width=110)
with hR:
    st.title("CommandCore")
    st.caption("Estimator (v2) + Ops Board (Kanban) + AI Parser + Admin Pricing")

# =========================
# Constants
# =========================
STATUS_ORDER = [
    ("NEW_WORK_ORDERS", "NEW WORK ORDERS"),
    ("READY_FOR_DISPATCH", "READY FOR DISPATCH ⚡"),
    ("IN_PROGRESS", "IN PROGRESS (FIELD ACTIVE)"),
    ("NEEDS_OFFICE_FOLLOW_UP", "NEEDS OFFICE FOLLOW-UP ⚡"),
    ("ESTIMATE_SUBMITTED_PENDING_APPROVAL", "ESTIMATE SUBMITTED — PENDING CLIENT APPROVAL"),
    ("WAITING_ON_PARTS_MATERIALS", "WAITING ON PARTS / MATERIALS"),
    ("READY_FOR_RETURN_ETA_NOT_SET", "READY FOR RETURN — ETA NOT SET"),
    ("READY_FOR_INVOICING", "READY FOR INVOICING ⚡"),
    ("INVOICED_PENDING_PAYMENT", "INVOICED — PENDING PAYMENT ⚡"),
]
STATUS_CODES = [s[0] for s in STATUS_ORDER]

URGENCY_OPTIONS = ["Emergency (4 hr)", "Same day", "24 HR", "48 HR", "72 HR", "Not Urgent"]
JOB_PRIORITY_OPTIONS = ["Low", "Normal", "High"]
REGION_OPTIONS = ["GA", "TN", "AL", "OTHER"]

MATERIALS_OPTIONS = ["None", "Materials needed", "Materials ordered", "Vendor-blocked"]
ESTIMATE_STATUS_OPTIONS = ["Not started", "Need estimate", "Estimate submitted", "Approved", "Declined"]

# =========================
# Helpers
# =========================
def _first_match(patterns: List[re.Pattern], text: str) -> str | None:
    for p in patterns:
        m = p.search(text)
        if m:
            return (m.group(1) or "").strip()
    return None

def supabase_ready() -> bool:
    return bool(SUPABASE_URL and SUPABASE_ANON_KEY)

def supabase_headers() -> Dict[str, str]:
    return {"apikey": SUPABASE_ANON_KEY, "Authorization": f"Bearer {SUPABASE_ANON_KEY}"}

def admin_ready() -> bool:
    return bool(SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY and ADMIN_PASSWORD)

def admin_headers() -> Dict[str, str]:
    return {
        "apikey": SUPABASE_SERVICE_ROLE_KEY,
        "Authorization": f"Bearer {SUPABASE_SERVICE_ROLE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates,return=representation",
    }

def sb_get(table: str, params: str) -> list[dict]:
    url = f"{SUPABASE_REST}/{table}?{params}"
    r = requests.get(url, headers=supabase_headers(), timeout=30)
    r.raise_for_status()
    return r.json()

def sb_insert_admin(table: str, payload: dict) -> list[dict]:
    url = f"{SUPABASE_REST}/{table}"
    r = requests.post(url, headers=admin_headers(), json=[payload], timeout=30)
    if not r.ok:
        raise RuntimeError(f"Insert failed ({r.status_code}): {r.text}")
    return r.json()

def sb_patch_admin(table: str, match_query: str, payload: dict) -> list[dict]:
    url = f"{SUPABASE_REST}/{table}?{match_query}"
    r = requests.patch(url, headers=admin_headers(), json=payload, timeout=30)
    if not r.ok:
        raise RuntimeError(f"Update failed ({r.status_code}): {r.text}")
    return r.json()

def sb_upsert_admin(table: str, payload: dict, on_conflict: str) -> list[dict]:
    url = f"{SUPABASE_REST}/{table}?on_conflict={on_conflict}"
    r = requests.post(url, headers=admin_headers(), json=[payload], timeout=30)
    if not r.ok:
        raise RuntimeError(f"Upsert failed ({r.status_code}): {r.text}")
    return r.json()

def sb_upsert_admin_bulk(table: str, payload: list[dict], on_conflict: str) -> list[dict]:
    if not payload:
        return []
    url = f"{SUPABASE_REST}/{table}?on_conflict={on_conflict}"
    r = requests.post(url, headers=admin_headers(), json=payload, timeout=30)
    if not r.ok:
        raise RuntimeError(f"Upsert failed ({r.status_code}): {r.text}")
    return r.json()

# =========================
# Estimator helpers
# =========================
EMERGENCY_REGEX = re.compile(r"\bemergency\b|\bafter\s*hours\b|\b4\s*hr\b|\b4hr\b", re.IGNORECASE)

def detect_emergency(text: str) -> bool:
    return bool(EMERGENCY_REGEX.search(text or ""))

def _money(x: float | None) -> str:
    if x is None:
        return "—"
    return f"${x:,.2f}"

def run_quote(
    customer_name: str,
    scope_text: str,
    techs: int,
    hours: float,
    include_materials: bool,
    materials_allowance: float,
    materials_top_n: int,
    materials_min_examples: int,
    pricebook_path: str,
    qb_sales_detail_path: str,
) -> Tuple[str, str]:
    if not customer_name:
        return "", "Customer is blank."
    if not QUOTE_SCRIPT.exists():
        return "", f"Missing quote engine: {QUOTE_SCRIPT}"
    if not Path(pricebook_path).exists():
        return "", f"Pricebook not found: {pricebook_path}"

    cmd = [
        sys.executable,
        str(QUOTE_SCRIPT),
        "--customer", customer_name,
        "--scope", scope_text,
        "--pricebook", pricebook_path,
        "--techs", str(int(techs)),
        "--hours", str(float(hours)),
    ]

    if qb_sales_detail_path and Path(qb_sales_detail_path).exists():
        cmd += ["--qb_sales_detail", qb_sales_detail_path]

    if include_materials:
        cmd.append("--materials")
        cmd += ["--materials_top_n", str(int(materials_top_n))]
        cmd += ["--materials_min_examples", str(int(materials_min_examples))]
        if materials_allowance and materials_allowance > 0:
            cmd += ["--materials_allowance", str(materials_allowance)]

    result = subprocess.run(cmd, capture_output=True, text=True)
    stdout = (result.stdout or "").strip()
    stderr = (result.stderr or "").strip()

    if result.returncode != 0:
        return stdout, f"Estimator returned non-zero exit code ({result.returncode}).\n\n{stderr}".strip()
    return stdout if stdout else "No output returned.", ""

def parse_output(raw: str) -> Dict[str, Any]:
    out = {"raw": raw, "totals": {}, "initial_nte": {}, "line_items": []}

    m = re.search(r"TOTAL \(median\): \$(\d+(\.\d+)?)", raw)
    if m: out["totals"]["median"] = float(m.group(1))
    m = re.search(r"TOTAL RANGE:\s*\$(\d+(\.\d+)?)\s*-\s*\$(\d+(\.\d+)?)", raw)
    if m:
        out["totals"]["min"] = float(m.group(1))
        out["totals"]["max"] = float(m.group(3))

    m = re.search(r"INITIAL NTE \(median\):\s*\$(\d+(\.\d+)?)", raw)
    if m: out["initial_nte"]["median"] = float(m.group(1))
    m = re.search(r"INITIAL NTE RANGE:\s*\$(\d+(\.\d+)?)\s*-\s*\$(\d+(\.\d+)?)", raw)
    if m:
        out["initial_nte"]["min"] = float(m.group(1))
        out["initial_nte"]["max"] = float(m.group(3))

    li_pat = re.compile(
        r"^(?P<svc>[A-Z0-9_]+):\s*\$(?P<med>\d+(\.\d+)?)\s*"
        r"\(range\s*\$(?P<min>\d+(\.\d+)?)\s*-\s*\$(?P<max>\d+(\.\d+)?)\)\s*"
        r"examples=(?P<ex>\d+)\s*source=(?P<src>.+)$"
    )
    for line in raw.splitlines():
        mm = li_pat.match(line.strip())
        if mm:
            out["line_items"].append({
                "service": mm.group("svc"),
                "median": float(mm.group("med")),
                "min": float(mm.group("min")),
                "max": float(mm.group("max")),
                "examples": int(mm.group("ex")),
                "source": mm.group("src").strip(),
            })
    return out

# =========================
# History helpers
# =========================
def ensure_data_dir():
    DATA_DIR.mkdir(exist_ok=True)

def append_history(record: Dict[str, Any]) -> None:
    ensure_data_dir()
    with (HISTORY_PATH).open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

def load_history() -> List[Dict[str, Any]]:
    if not HISTORY_PATH.exists():
        return []
    rows = []
    with HISTORY_PATH.open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                try:
                    rows.append(json.loads(line))
                except Exception:
                    pass
    return rows

# =========================
# SAFE decision reset BEFORE widgets
# =========================
if st.session_state.get("_reset_decision_after_quote") and st.session_state.get("_suggested_final_price") is not None:
    st.session_state["decision_final_price_input"] = float(st.session_state.get("_suggested_final_price") or 0.0)
    st.session_state["decision_status"] = "Draft"
    st.session_state["decision_job_number"] = ""
    st.session_state["decision_notes"] = ""
    st.session_state["_reset_decision_after_quote"] = False

if "jobs_refresh_nonce" not in st.session_state:
    st.session_state["jobs_refresh_nonce"] = 0

def bump_jobs_refresh() -> None:
    st.session_state["jobs_refresh_nonce"] += 1

if "notes_refresh_nonce" not in st.session_state:
    st.session_state["notes_refresh_nonce"] = 0

def bump_notes_refresh() -> None:
    st.session_state["notes_refresh_nonce"] += 1

if "reset_note_after_add" not in st.session_state:
    st.session_state["reset_note_after_add"] = False

# =========================
# Parser: regex hint + AI
# =========================
WO_PATTERNS = [
    re.compile(r"\bWO[#:\s]*([A-Za-z0-9\-_]+)\b", re.IGNORECASE),
    re.compile(r"\bWork\s*Order[#:\s]*([A-Za-z0-9\-_]+)\b", re.IGNORECASE),
]
PO_PATTERNS = [
    re.compile(r"\bPO[#:\s]*([A-Za-z0-9\-_]+)\b", re.IGNORECASE),
    re.compile(r"\bVendor\s*PO[#:\s]*([A-Za-z0-9\-_]+)\b", re.IGNORECASE),
]
ADDRESS_HINT = re.compile(r"\b\d{1,6}\s+[A-Za-z0-9][A-Za-z0-9\s\.\-#]{3,}\b")
EMERGENCY_HINT = re.compile(r"\bemergency\b|\bafter\s*hours\b|\b4\s*hr\b|\b4hr\b|\basap\b", re.IGNORECASE)

def regex_hint_parse_wo(raw: str) -> dict:
    t = (raw or "").strip().replace("\r\n", "\n")
    wo = _first_match(WO_PATTERNS, t) or ""
    po = _first_match(PO_PATTERNS, t) or ""
    addr = ""
    for line in t.splitlines():
        if ADDRESS_HINT.search(line):
            addr = line.strip()
            break
    urgency = "Emergency (4 hr)" if EMERGENCY_HINT.search(t) else "24 HR"
    priority = "High" if urgency in ("Emergency (4 hr)", "Same day") else "Normal"
    scope = re.sub(r"(?im)^(from|to|subject|sent|date):.*$", "", t).strip()
    scope = re.sub(r"\n{3,}", "\n\n", scope).strip()[:900]
    return {"wo_number": wo, "po_number": po, "site_address": addr, "urgency": urgency, "job_priority": priority, "scope": scope}

WORK_ORDER_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "client_name": {"type": "string"},
        "store_name": {"type": "string"},
        "wo_number": {"type": "string"},
        "po_number": {"type": "string"},
        "site_address": {"type": "string"},
        "city": {"type": "string"},
        "state": {"type": "string"},
        "zip": {"type": "string"},
        "region": {"type": "string", "enum": REGION_OPTIONS},
        "urgency": {"type": "string", "enum": URGENCY_OPTIONS},
        "job_priority": {"type": "string", "enum": JOB_PRIORITY_OPTIONS},
        "job_type": {"type": "string"},
        "follow_up_required": {"type": "boolean"},
        "materials_status": {"type": "string", "enum": MATERIALS_OPTIONS},
        "material_notes": {"type": "string"},
        "estimate_status": {"type": "string", "enum": ESTIMATE_STATUS_OPTIONS},
        "invoice_number": {"type": "string"},
        "nte": {"type": ["number", "null"]},
        "scope_clean": {"type": "string"},
        "parser_confidence": {"type": "number", "minimum": 0, "maximum": 1},
        "needs_review": {"type": "boolean"},
        "extraction_notes": {"type": "string"},
    },
    "required": [
        "client_name","store_name","wo_number","po_number","site_address","city","state","zip","region",
        "urgency","job_priority","job_type","follow_up_required","materials_status","material_notes",
        "estimate_status","invoice_number","nte","scope_clean","parser_confidence","needs_review","extraction_notes"
    ],
}

def ai_parse_work_order(raw_text: str, hint: dict) -> dict:
    if not oa_client:
        raise RuntimeError("OPENAI_API_KEY missing in .env")
    system = (
        "Extract structured work order fields from facility maintenance emails.\n"
        "Do NOT hallucinate. Unknown -> empty string or null.\n"
        "WO#: prefer long numeric IDs; avoid tiny fragments.\n"
        "scope_clean: remove boilerplate; keep actual work description.\n"
        "If confidence < 0.6 set needs_review=true.\n"
        "Return JSON matching the schema.\n"
    )
    user = f"RAW_TEXT:\n{raw_text}\n\nREGEX_HINT_JSON:\n{json.dumps(hint, ensure_ascii=False)}\n"

    resp = oa_client.responses.create(
        model="gpt-4o-mini",
        input=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        text={
            "format": {
                "type": "json_schema",
                "name": "work_order_extract",
                "schema": WORK_ORDER_SCHEMA,
                "strict": True,
            }
        },
        store=False,
    )

    if getattr(resp, "output_parsed", None):
        return resp.output_parsed
    if getattr(resp, "output_text", None):
        return json.loads(resp.output_text)
    raise RuntimeError("OpenAI response empty/unreadable.")

# =========================
# Cached fetches
# =========================
@st.cache_data(ttl=30)
def fetch_work_orders(limit: int = 500, refresh_nonce: int = 0) -> List[dict]:
    params = (
        "select=id,client_name,store_name,urgency,job_priority,region,wo_number,city,po_number,"
        "job_type,status,site_address,scope,nte,materials_status,material_notes,estimate_status,"
        "follow_up_required,invoice_number,assigned_tech_id,updated_at,created_at,sla_override_hours,status_rank"
        f"&order=status_rank.asc.nullslast,created_at.desc&limit={int(limit)}"
    )
    return sb_get("work_orders", params)

@st.cache_data(ttl=60)
def fetch_techs() -> List[dict]:
    try:
        return sb_get("techs", "select=id,name&is_active=eq.true&order=name.asc&limit=5000")
    except Exception:
        return []

def tech_name_map(techs: List[dict]) -> Dict[str, str]:
    return {t["id"]: t["name"] for t in techs if t.get("id")}

@st.cache_data(ttl=30)
def fetch_job_notes(work_order_id: str, refresh_nonce: int = 0) -> List[dict]:
    params = (
        "select=id,work_order_id,note_type,body,created_at,created_by"
        f"&work_order_id=eq.{urlquote(work_order_id)}"
        "&order=created_at.desc&limit=500"
    )
    return sb_get("job_notes", params)

# =========================
# Admin pricing helpers
# =========================
@st.cache_data(ttl=120)
def fetch_pb_items() -> List[dict]:
    if not supabase_ready():
        return []
    return sb_get("pb_items", "select=id,name,item_code,item_type,unit,base_price,min_price,max_price,is_active&order=name.asc&limit=10000")

@st.cache_data(ttl=120)
def fetch_client_overrides(client_name: str) -> List[dict]:
    if not supabase_ready() or not client_name.strip():
        return []
    params = (
        "select=client_name,override_price,notes,is_active,pb_items(name)"
        f"&client_name=eq.{urlquote(client_name.strip())}"
        "&limit=5000"
    )
    return sb_get("pb_client_overrides", params)

# =========================
# Kanban helpers
# =========================
def urgency_class(u: str) -> str:
    if u == "Emergency (4 hr)":
        return "cc-badge cc-badge-emergency"
    if u in ("Same day", "24 HR"):
        return "cc-badge cc-badge-med"
    return "cc-badge cc-badge-low"

def short(s: str, n: int = 85) -> str:
    s = (s or "").strip()
    return s if len(s) <= n else s[: n - 1].rstrip() + "…"

def parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)

def human_age(delta: timedelta) -> str:
    seconds = max(0, int(delta.total_seconds()))
    minutes = seconds // 60
    if minutes < 1:
        return "0m"
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h"
    days = hours // 24
    if days < 7:
        return f"{days}d"
    weeks = days // 7
    return f"{weeks}w"

SLA_HOURS = {
    "Emergency (4 hr)": 4,
    "Same day": 12,
    "24 HR": 24,
    "48 HR": 48,
    "72 HR": 72,
    "Not Urgent": None,
}

URGENCY_RANK = {
    "Emergency (4 hr)": 5,
    "Same day": 4,
    "24 HR": 3,
    "48 HR": 2,
    "72 HR": 1,
    "Not Urgent": 0,
}

def resolve_sla_hours(urgency: str, override_hours: Any) -> float | None:
    if override_hours is not None:
        try:
            override_value = float(override_hours)
        except (TypeError, ValueError):
            override_value = None
        if override_value and override_value > 0:
            return override_value
    return SLA_HOURS.get(urgency)

def sla_badge(
    urgency: str,
    created_at: datetime | None,
    now: datetime,
    override_hours: Any = None,
) -> tuple[str | None, str | None]:
    sla_hours = resolve_sla_hours(urgency, override_hours)
    if not sla_hours or not created_at:
        return None, None
    due_at = created_at + timedelta(hours=sla_hours)
    remaining_seconds = (due_at - now).total_seconds()
    if remaining_seconds <= 0:
        return "SLA OVERDUE", "cc-pill cc-pill-danger"
    threshold_seconds = max(4 * 3600, sla_hours * 0.25 * 3600)
    if remaining_seconds <= threshold_seconds:
        return "SLA RISK", "cc-pill cc-pill-warn"
    return None, None

def risk_sort_key(row: dict, now: datetime) -> tuple:
    urgency = row.get("urgency") or "Not Urgent"
    created_at = parse_dt(row.get("created_at")) or now
    updated_at = parse_dt(row.get("updated_at")) or created_at
    idle_seconds = max(0.0, (now - updated_at).total_seconds())
    age_seconds = max(0.0, (now - created_at).total_seconds())

    sla_hours = resolve_sla_hours(urgency, row.get("sla_override_hours"))
    overdue = False
    if sla_hours and created_at:
        overdue = now > (created_at + timedelta(hours=sla_hours))

    urgency_rank = URGENCY_RANK.get(urgency, 0)
    return (-urgency_rank, -int(overdue), -idle_seconds, -age_seconds)

def kanban_sort_key(row: dict, now: datetime) -> tuple:
    rank = row.get("status_rank")
    created_at = parse_dt(row.get("created_at")) or now
    created_ts = created_at.timestamp()
    return (rank is None, rank if rank is not None else 0, -created_ts)

def normalize_field_value(field: str, value: Any) -> Any:
    text_none_fields = {
        "store_name",
        "wo_number",
        "po_number",
        "city",
        "job_type",
        "site_address",
        "invoice_number",
        "material_notes",
    }
    text_required_fields = {"client_name", "scope"}

    if field in text_none_fields:
        normalized = (value or "").strip()
        return normalized or None
    if field in text_required_fields:
        return (value or "").strip()
    if field == "nte":
        if value is None:
            return None
        try:
            num = float(value)
        except (TypeError, ValueError):
            return None
        return num if num > 0 else None
    if field == "sla_override_hours":
        if value is None:
            return None
        try:
            num = float(value)
        except (TypeError, ValueError):
            return None
        return num if num > 0 else None
    if field == "follow_up_required":
        return bool(value)
    return value

def format_note_value(field: str, value: Any, tech_map: Dict[str, str]) -> str:
    if field == "assigned_tech_id":
        return tech_map.get(value, "(unassigned)") if value else "(unassigned)"
    if field == "nte":
        return f"${float(value):,.2f}" if value is not None else "(blank)"
    if field == "sla_override_hours":
        return f"{float(value):g}h" if value is not None else "(blank)"
    if field == "follow_up_required":
        return "Yes" if value else "No"
    if value is None or (isinstance(value, str) and not value.strip()):
        return "(blank)"
    return str(value)

# =========================
# Sidebar
# =========================
st.sidebar.header("System")
st.sidebar.write({"supabase_ready": supabase_ready(), "admin_ready": admin_ready(), "ai_ready": bool(OPENAI_API_KEY)})

# =========================
# Tabs
# =========================
tabs = st.tabs(["Estimator (v2)", "Work Orders (Kanban)", "Admin (Pricing)"])

# =========================================================
# TAB 1: Estimator (v2)
# =========================================================
with tabs[0]:
    st.sidebar.header("Estimator Files")
    pricebook_path = st.sidebar.text_input("Legacy Pricebook CSV (fallback only)", DEFAULT_PRICEBOOK)
    qb_sales_detail_path = st.sidebar.text_input("QB Sales Detail CSV (evidence)", str(DEFAULT_QB_SALES_DETAIL))

    customers = []
    if Path(pricebook_path).exists():
        try:
            df = pd.read_csv(pricebook_path)
            df.columns = [c.strip() for c in df.columns]
            if "Customer full name" in df.columns:
                customers = sorted(df["Customer full name"].dropna().astype(str).unique().tolist())
        except Exception:
            customers = []

    left_col, right_col = st.columns([0.95, 1.55], gap="large")
    latest_quote = st.session_state.get("latest_quote")

    with left_col:
        st.markdown('<div class="cc-sticky">', unsafe_allow_html=True)

        st.markdown('<div class="cc-card">', unsafe_allow_html=True)
        st.subheader("Job Details")
        customer = st.selectbox("Customer", options=customers if customers else ["(type manually)"])
        customer_final = customer.strip()
        manual_override = st.text_input("Customer full name (optional override)", value="")
        if manual_override.strip():
            customer_final = manual_override.strip()

        scope = st.text_area("Scope (what are we doing?)", value="trip and labor", height=120)
        if detect_emergency(scope):
            st.markdown("<span class='cc-badge cc-badge-emergency'>Emergency detected</span>", unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="cc-card">', unsafe_allow_html=True)
        st.subheader("Labor & Timing")
        c1, c2 = st.columns(2)
        techs_i = c1.selectbox("Techs", options=[1, 2, 3, 4], index=0)
        hours = c2.number_input("Hours per tech", min_value=0.5, step=0.5, value=1.0)
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="cc-card">', unsafe_allow_html=True)
        st.subheader("Materials")
        include_materials = st.checkbox("Include materials", value=False)
        st.markdown("<div class='cc-muted'>Leave materials OFF unless replacing/installing parts.</div>", unsafe_allow_html=True)
        materials_allowance = 0.0
        materials_top_n = 3
        materials_min_examples = 3
        if include_materials:
            m1, m2, m3 = st.columns([1, 1, 2])
            materials_allowance = m1.number_input("Materials allowance (optional)", min_value=0.0, step=25.0, value=0.0)
            materials_top_n = m2.number_input("Evidence lines per bucket", min_value=1, max_value=10, step=1, value=3)
            materials_min_examples = m3.number_input("Min customer examples", min_value=1, max_value=50, step=1, value=3)
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="cc-card">', unsafe_allow_html=True)
        st.subheader("Actions")
        run_btn = st.button("Generate Quote", type="primary", use_container_width=True)

        st.markdown("**Decision capture**")
        st.number_input("Final chosen price", min_value=0.0, step=25.0, key="decision_final_price_input")
        st.selectbox("Status", options=["Draft", "Sent", "Approved", "Scheduled", "Completed"], key="decision_status")
        st.text_input("Work Order / Job number (optional)", key="decision_job_number")
        st.text_area("Notes", key="decision_notes", height=110)

        if latest_quote is not None:
            if st.button("Save Decision to History", use_container_width=True):
                record = {
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "customer": latest_quote.get("customer"),
                    "scope": latest_quote.get("scope"),
                    "totals": latest_quote.get("parsed", {}).get("totals", {}),
                    "initial_nte": latest_quote.get("parsed", {}).get("initial_nte", {}),
                    "line_items": latest_quote.get("parsed", {}).get("line_items", []),
                    "raw_output": latest_quote.get("raw_output", ""),
                    "decision": {
                        "final_price": st.session_state.get("decision_final_price_input"),
                        "status": st.session_state.get("decision_status"),
                        "job_number": st.session_state.get("decision_job_number"),
                        "notes": st.session_state.get("decision_notes"),
                    },
                }
                append_history(record)
                st.toast("Saved.")
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

    if run_btn:
        with st.spinner("Running estimator..."):
            stdout, err = run_quote(
                customer_final,
                scope,
                int(techs_i),
                float(hours),
                bool(include_materials),
                float(materials_allowance),
                int(materials_top_n),
                int(materials_min_examples),
                str(pricebook_path),
                str(qb_sales_detail_path),
            )
        if err:
            st.error("Estimator error")
            st.code(err, language="text")
        else:
            parsed = parse_output(stdout)
            st.session_state["latest_quote"] = {
                "customer": customer_final,
                "scope": scope,
                "raw_output": stdout,
                "parsed": parsed,
            }
            st.session_state["_suggested_final_price"] = float(parsed["totals"].get("median") or 0.0)
            st.session_state["_reset_decision_after_quote"] = True
            st.toast("Quote ready.")
            st.rerun()

    with right_col:
        if latest_quote:
            parsed = latest_quote["parsed"]
            st.markdown('<div class="cc-card">', unsafe_allow_html=True)
            st.subheader("Results Dashboard")
            total_med = parsed["totals"].get("median")
            total_min = parsed["totals"].get("min")
            total_max = parsed["totals"].get("max")
            init_med = parsed["initial_nte"].get("median")
            init_min = parsed["initial_nte"].get("min")
            init_max = parsed["initial_nte"].get("max")

            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Total (median)", _money(total_med))
            m2.metric("Total range", f"{_money(total_min)} → {_money(total_max)}")
            m3.metric("Initial NTE (median)", _money(init_med))
            m4.metric("Initial NTE range", f"{_money(init_min)} → {_money(init_max)}")
            st.markdown("</div>", unsafe_allow_html=True)

            st.markdown('<div class="cc-card">', unsafe_allow_html=True)
            st.subheader("Details")
            t2 = st.tabs(["Line Items", "Raw Output", "History"])
            with t2[0]:
                items = parsed.get("line_items", [])
                st.dataframe(pd.DataFrame(items) if items else pd.DataFrame(), use_container_width=True)
            with t2[1]:
                st.code(latest_quote["raw_output"], language="text")
            with t2[2]:
                hist = load_history()
                st.dataframe(pd.DataFrame(hist) if hist else pd.DataFrame(), use_container_width=True)
            st.markdown("</div>", unsafe_allow_html=True)
        else:
            st.markdown('<div class="cc-card">', unsafe_allow_html=True)
            st.subheader("Results Dashboard")
            st.markdown("<div class='cc-subtle'>Run the estimator to see results.</div>", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)

# =========================================================
# TAB 2: Work Orders (KANBAN + RIGHT DETAILS PANE)
# =========================================================
with tabs[1]:
    if not supabase_ready():
        st.error("Supabase not configured.")
        st.stop()

    techs = fetch_techs()
    tech_map = tech_name_map(techs)

    left, right = st.columns([1.35, 0.65], gap="large")

    with left:
        st.markdown('<div class="cc-card">', unsafe_allow_html=True)
        st.subheader("Work Orders (Kanban Board)")

        st.markdown("**Admin Password (required to create + move + edit)**")
        st.text_input("Password", type="password", key="wo_admin_pw")

        st.markdown("### Intake (Paste Email → AI Parse → Create)")
        colA, colB = st.columns([1.2, 0.8])
        with colA:
            raw_email = st.text_area("Paste Email Text", height=170)
            pdf_text = ""
            pdf_extraction_error = False
            pdf_file = st.file_uploader("Upload PDF (optional)", type=["pdf"], key="intake_pdf")
            if pdf_file is not None:
                pdf_bytes = pdf_file.read()
                try:
                    reader = PdfReader(io.BytesIO(pdf_bytes))
                    pdf_chunks = []
                    for page in reader.pages:
                        page_text = page.extract_text()
                        if page_text:
                            pdf_chunks.append(page_text)
                    pdf_text = "\n".join(pdf_chunks).strip()
                except Exception:
                    pdf_extraction_error = True
                    st.error("Could not extract text from PDF. Falling back to email text only.")
                if pdf_text:
                    preview = pdf_text[:1200]
                    st.caption("PDF extracted text preview")
                    st.text_area("", value=preview, height=120, disabled=True, key="pdf_preview")
            parse_btn = st.button("Parse & Fill", type="secondary")
        if raw_email and pdf_text:
            combined_text = raw_email + "\n\n--- PDF TEXT ---\n\n" + pdf_text
        elif pdf_text:
            combined_text = pdf_text
        else:
            combined_text = raw_email
        parsed_fields = st.session_state.get("wo_parsed_fields", {})
        intake_defaults = {
            "intake_client": "",
            "intake_store": "",
            "intake_wo": "",
            "intake_po": "",
            "intake_city": "",
            "intake_address": "",
            "intake_scope": "",
            "intake_urgency": "24 HR",
            "intake_priority": "Normal",
            "intake_region": "OTHER",
        }
        for key, default in intake_defaults.items():
            if key not in st.session_state:
                st.session_state[key] = default

        if parse_btn:
            if not OPENAI_API_KEY:
                st.error("OPENAI_API_KEY missing in .env")
                st.stop()
            with st.spinner("AI parsing..."):
                text_to_parse = raw_email if pdf_extraction_error else combined_text
                hint = regex_hint_parse_wo(text_to_parse)
                parsed_fields = ai_parse_work_order(text_to_parse, hint)
                st.session_state["wo_parsed_fields"] = parsed_fields
                st.session_state["intake_client"] = parsed_fields.get("client_name", "")
                st.session_state["intake_store"] = parsed_fields.get("store_name", "")
                st.session_state["intake_wo"] = parsed_fields.get("wo_number", "")
                st.session_state["intake_po"] = parsed_fields.get("po_number", "")
                st.session_state["intake_city"] = parsed_fields.get("city", "")
                st.session_state["intake_address"] = parsed_fields.get("site_address", "")
                st.session_state["intake_scope"] = parsed_fields.get("scope_clean", "")
                parsed_urgency = parsed_fields.get("urgency", "24 HR")
                st.session_state["intake_urgency"] = parsed_urgency if parsed_urgency in URGENCY_OPTIONS else "24 HR"
                parsed_priority = parsed_fields.get("job_priority", "Normal")
                st.session_state["intake_priority"] = parsed_priority if parsed_priority in JOB_PRIORITY_OPTIONS else "Normal"
                parsed_region = parsed_fields.get("region", "OTHER")
                st.session_state["intake_region"] = parsed_region if parsed_region in REGION_OPTIONS else "OTHER"
            st.toast(f"AI Parsed (confidence {parsed_fields.get('parser_confidence')}).")

        with colB:
            st.markdown("**AI Output**")
            st.json(parsed_fields) if parsed_fields else st.caption("Click Parse & Fill")

        client = st.text_input("Client", key="intake_client")
        store = st.text_input("Store Name", key="intake_store")

        c1, c2, c3 = st.columns(3)
        wo_number = c1.text_input("WO #", key="intake_wo")
        po_number = c2.text_input("PO #", key="intake_po")
        city = c3.text_input("City", key="intake_city")

        c4, c5, c6 = st.columns(3)
        urgency = c4.selectbox("Urgency", URGENCY_OPTIONS, key="intake_urgency")
        job_priority = c5.selectbox("Job Priority", JOB_PRIORITY_OPTIONS, key="intake_priority")
        region = c6.selectbox("Region", REGION_OPTIONS, key="intake_region")

        address = st.text_input("Address", key="intake_address")
        scope_wo = st.text_area("Description of Work", height=105, key="intake_scope")

        if st.button("Create Work Order", type="primary"):
            if not admin_ready():
                st.error("Admin not configured.")
                st.stop()
            if st.session_state.get("wo_admin_pw") != ADMIN_PASSWORD:
                st.error("Wrong admin password.")
                st.stop()
            if not client.strip():
                st.error("Client is required.")
                st.stop()
            if not scope_wo.strip():
                st.error("Description of Work is required.")
                st.stop()

            payload = {
                "client_name": client.strip(),
                "store_name": store.strip() or None,
                "urgency": urgency,
                "job_priority": job_priority,
                "region": region,
                "wo_number": wo_number.strip() or None,
                "po_number": po_number.strip() or None,
                "city": city.strip() or None,
                "job_type": parsed_fields.get("job_type", "") or "",
                "assigned_tech_id": None,
                "follow_up_required": bool(parsed_fields.get("follow_up_required") or False),
                "invoice_number": parsed_fields.get("invoice_number", "") or None,
                "materials_status": parsed_fields.get("materials_status", "None") or "None",
                "material_notes": parsed_fields.get("material_notes", "") or None,
                "scope": scope_wo.strip(),
                "estimate_status": parsed_fields.get("estimate_status", "Not started") or "Not started",
                "site_address": address.strip() or None,
                "nte": float(parsed_fields.get("nte") or 0.0) if parsed_fields.get("nte") else None,
                "status": "NEW_WORK_ORDERS",
                "raw_email_text": combined_text.strip() or None,
                "parser_confidence": float(parsed_fields.get("parser_confidence") or 0.0),
                "needs_review": bool(parsed_fields.get("needs_review") or False),
                "parser_version": "v2-ai",
            }

            try:
                created = sb_insert_admin("work_orders", payload)
                new_id = created[0].get("id")
                st.success(f"Created work order: {new_id}")
                st.session_state.pop("wo_parsed_fields", None)
                st.session_state["selected_wo_id"] = new_id
                bump_jobs_refresh()
                st.rerun()
            except Exception as e:
                st.error(str(e))

        st.divider()

        colX, colY, colZ = st.columns([1, 1, 1])
        with colX:
            if st.button("Reload Board"):
                bump_jobs_refresh()
                st.rerun()
        with colY:
            limit = st.number_input("Rows", min_value=50, max_value=2000, step=50, value=500)
        with colZ:
            if ENABLE_CUSTOM_KANBAN and CUSTOM_KANBAN_AVAILABLE:
                st.caption("Custom Kanban enabled (drag to move).")
            elif ENABLE_CUSTOM_KANBAN:
                st.caption(f"Custom Kanban unavailable (fallback board active). Import error: {CUSTOM_KANBAN_ERR}")
            else:
                st.caption("Custom Kanban disabled.")

        rows = fetch_work_orders(limit=int(limit), refresh_nonce=st.session_state["jobs_refresh_nonce"])
        if not rows:
            st.warning("No work orders returned from Supabase yet.")
            st.stop()

        by_status: Dict[str, List[dict]] = {code: [] for code, _ in STATUS_ORDER}
        unmapped: List[dict] = []
        for r in rows:
            st_code = (r.get("status") or "").strip()
            if st_code in by_status:
                by_status[st_code].append(r)
            else:
                unmapped.append(r)

        now = datetime.now(timezone.utc)
        for code in by_status:
            by_status[code] = sorted(by_status[code], key=lambda row: kanban_sort_key(row, now))

        board_state = {code: [r.get("id") for r in by_status[code] if r.get("id")] for code, _ in STATUS_ORDER}
        wo_by_id = {r.get("id"): r for r in rows if r.get("id")}
        editable = admin_ready() and (st.session_state.get("wo_admin_pw") == ADMIN_PASSWORD)
        use_custom_kanban = ENABLE_CUSTOM_KANBAN and CUSTOM_KANBAN_AVAILABLE

        if use_custom_kanban:
            def build_rank_payload(order: List[str]) -> List[dict]:
                return [{"id": wo_id, "status_rank": idx} for idx, wo_id in enumerate(order)]

            columns_payload = [
                {"id": code, "title": label, "count": len(by_status[code])} for code, label in STATUS_ORDER
            ]
            items_payload: List[dict] = []
            for status_code, _ in STATUS_ORDER:
                for row in by_status[status_code]:
                    wo_id = row.get("id")
                    if not wo_id:
                        continue
                    wo_disp = row.get("wo_number") or (wo_id[:8] if wo_id else "WO")
                    client_disp = row.get("client_name") or ""
                    store_disp = row.get("store_name") or ""
                    city_disp = row.get("city") or ""
                    urg = row.get("urgency") or "24 HR"
                    pri = row.get("job_priority") or "Normal"
                    reg = row.get("region") or ""
                    scope_txt = row.get("scope") or ""
                    created_at = parse_dt(row.get("created_at")) or now
                    updated_at = parse_dt(row.get("updated_at")) or created_at
                    age_label = human_age(now - created_at)
                    idle_label = human_age(now - updated_at)
                    sla_label, _ = sla_badge(urg, created_at, now, row.get("sla_override_hours"))

                    badges = [f"Age: {age_label}", f"Idle: {idle_label}"]
                    if sla_label:
                        badges.append(sla_label)

                    items_payload.append(
                        {
                            "id": wo_id,
                            "columnId": status_code,
                            "title": wo_disp,
                            "subtitle": client_disp,
                            "badges": badges,
                            "meta": {
                                "urgency": urg,
                                "subtitle": f"{store_disp} · {city_disp} · {reg} · {pri}",
                                "scope": short(scope_txt, 95),
                            },
                        }
                    )

            kanban_event = cc_kanban_component(
                columns=columns_payload,
                items=items_payload,
                selected_id=st.session_state.get("selected_wo_id"),
                enable_reorder=editable,
                key="cc_kanban",
            )

            if kanban_event and kanban_event != st.session_state.get("cc_kanban_last_event"):
                st.session_state["cc_kanban_last_event"] = kanban_event
                event_type = kanban_event.get("type") if isinstance(kanban_event, dict) else None
                if event_type == "OPEN":
                    selected_id = kanban_event.get("id")
                    if selected_id:
                        st.session_state["selected_wo_id"] = selected_id
                        st.rerun()
                elif event_type == "MOVE":
                    move_id = kanban_event.get("id")
                    from_status = kanban_event.get("from")
                    to_status = kanban_event.get("to")
                    to_order = kanban_event.get("toOrder") or []
                    from_order = kanban_event.get("fromOrder") or []
                    if not move_id or not from_status or not to_status:
                        st.error("Invalid drag event payload.")
                        bump_jobs_refresh()
                        st.rerun()
                    elif not admin_ready():
                        st.error("Admin not configured.")
                        bump_jobs_refresh()
                        st.rerun()
                    elif st.session_state.get("wo_admin_pw") != ADMIN_PASSWORD:
                        st.error("Wrong admin password.")
                        bump_jobs_refresh()
                        st.rerun()
                    else:
                        status_changed = from_status != to_status
                        try:
                            if status_changed:
                                sb_patch_admin(
                                    "work_orders",
                                    f"id=eq.{urlquote(move_id)}",
                                    {"status": to_status},
                                )

                            rank_payload: List[dict] = []
                            if to_order:
                                rank_payload.extend(build_rank_payload([str(x) for x in to_order]))
                            if status_changed and from_order:
                                rank_payload.extend(build_rank_payload([str(x) for x in from_order]))

                            if rank_payload:
                                sb_upsert_admin_bulk("work_orders", rank_payload, "id")

                            note_body = (
                                f"Status: {from_status} → {to_status}"
                                if status_changed
                                else f"Reordered within {from_status}"
                            )
                            try:
                                sb_insert_admin(
                                    "job_notes",
                                    {
                                        "work_order_id": move_id,
                                        "note_type": "system",
                                        "body": note_body,
                                    },
                                )
                                bump_notes_refresh()
                            except Exception as e:
                                st.error(f"Failed to log activity: {e}")

                            bump_jobs_refresh()
                            bump_notes_refresh()
                            st.toast("Board updated.")
                            st.rerun()
                        except Exception as e:
                            st.error(f"Drag update failed: {e}")
                            bump_jobs_refresh()
                            st.rerun()
        else:
            if ENABLE_CUSTOM_KANBAN and not CUSTOM_KANBAN_AVAILABLE:
                st.caption(f"Custom Kanban unavailable. Falling back to basic board. Import error: {CUSTOM_KANBAN_ERR}")
            elif not ENABLE_CUSTOM_KANBAN:
                st.caption("Custom Kanban disabled via ENABLE_CUSTOM_KANBAN.")

            def render_wo_card_basic(row: dict, status_code: str) -> None:
                wo_id = row.get("id")
                wo_disp = row.get("wo_number") or (wo_id[:8] if wo_id else "WO")
                client_disp = row.get("client_name") or ""
                store_disp = row.get("store_name") or ""
                city_disp = row.get("city") or ""
                urg = row.get("urgency") or "24 HR"
                pri = row.get("job_priority") or "Normal"
                reg = row.get("region") or ""
                scope_txt = row.get("scope") or ""
                created_at = parse_dt(row.get("created_at")) or now
                updated_at = parse_dt(row.get("updated_at")) or created_at
                age_label = human_age(now - created_at)
                idle_label = human_age(now - updated_at)
                sla_label, sla_class = sla_badge(urg, created_at, now, row.get("sla_override_hours"))

                st.markdown("<div class='wo-card'>", unsafe_allow_html=True)
                st.markdown(
                    f"<div class='wo-topline'>"
                    f"<div class='wo-wo'>{wo_disp}</div>"
                    f"<span class='{urgency_class(urg)}'>{urg}</span>"
                    f"</div>",
                    unsafe_allow_html=True,
                )
                badges = [
                    f"<span class='cc-pill'>Age: {age_label}</span>",
                    f"<span class='cc-pill'>Idle: {idle_label}</span>",
                ]
                if sla_label and sla_class:
                    badges.append(f"<span class='{sla_class}'>{sla_label}</span>")
                st.markdown(f"<div class='wo-meta'>{''.join(badges)}</div>", unsafe_allow_html=True)
                st.markdown(f"<div class='wo-client'>{client_disp}</div>", unsafe_allow_html=True)
                st.markdown(f"<div class='wo-sub'>{store_disp} · {city_disp} · {reg} · {pri}</div>", unsafe_allow_html=True)
                st.markdown(f"<div class='wo-scope'>{short(scope_txt, 95)}</div>", unsafe_allow_html=True)

                if st.button("Open", key=f"open_{status_code}_{wo_id}", use_container_width=True):
                    st.session_state["selected_wo_id"] = wo_id
                    st.rerun()

                with st.form(key=f"fallback_move_form_{wo_id}", clear_on_submit=False):
                    new_status = st.selectbox(
                        "Move to",
                        options=STATUS_CODES,
                        index=STATUS_CODES.index(status_code),
                        key=f"fallback_move_select_{wo_id}",
                        label_visibility="collapsed",
                    )
                    move_btn = st.form_submit_button("Move")

                    if move_btn:
                        if not admin_ready():
                            st.error("Admin not configured.")
                        elif st.session_state.get("wo_admin_pw") != ADMIN_PASSWORD:
                            st.error("Wrong admin password.")
                        else:
                            try:
                                sb_patch_admin("work_orders", f"id=eq.{urlquote(wo_id)}", {"status": new_status})
                                old_status = (row.get("status") or status_code)
                                if new_status != old_status:
                                    try:
                                        sb_insert_admin(
                                            "job_notes",
                                            {
                                                "work_order_id": wo_id,
                                                "note_type": "system",
                                                "body": f"Status: {old_status} → {new_status}",
                                            },
                                        )
                                        bump_notes_refresh()
                                    except Exception as e:
                                        st.error(f"Failed to log activity: {e}")
                                bump_jobs_refresh()
                                st.toast("Moved.")
                                st.rerun()
                            except Exception as e:
                                st.error(str(e))

                st.markdown("</div>", unsafe_allow_html=True)

            def render_status_column(col, status_code, status_label):
                with col:
                    st.markdown("<div class='kanban-col'>", unsafe_allow_html=True)
                    st.markdown(f"<div class='kanban-title'>{status_label} ({len(by_status[status_code])})</div>", unsafe_allow_html=True)

                    ordered_ids = board_state[status_code]
                    for wo_id in ordered_ids:
                        row = wo_by_id.get(wo_id)
                        if not row:
                            continue
                        render_wo_card_basic(row, status_code)

                    st.markdown("</div>", unsafe_allow_html=True)

            row1 = STATUS_ORDER[:5]
            row2 = STATUS_ORDER[5:]
            cols1 = st.columns(len(row1), gap="small")
            for i, (code, label) in enumerate(row1):
                render_status_column(cols1[i], code, label)

            st.markdown("")

            cols2 = st.columns(len(row2), gap="small")
            for i, (code, label) in enumerate(row2):
                render_status_column(cols2[i], code, label)

        if unmapped:
            st.divider()
            st.warning(f"{len(unmapped)} work orders have an unmapped status.")
            st.dataframe(pd.DataFrame(unmapped), use_container_width=True, hide_index=True)

        st.markdown("</div>", unsafe_allow_html=True)

    # -------------------------
    # RIGHT: Details Pane (with unique widget keys)
    # -------------------------
    with right:
        st.markdown('<div class="cc-card">', unsafe_allow_html=True)
        st.subheader("Job Details")

        selected_id = st.session_state.get("selected_wo_id")
        if not selected_id:
            st.markdown("<div class='cc-subtle'>Click <b>Open</b> on a card to view details here.</div>", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)
        else:
            try:
                details = sb_get(
                    "work_orders",
                    "select=id,client_name,store_name,urgency,job_priority,region,wo_number,city,po_number,"
                    "job_type,status,site_address,scope,nte,materials_status,material_notes,estimate_status,"
                    "follow_up_required,invoice_number,assigned_tech_id,updated_at,created_at,sla_override_hours"
                    f"&id=eq.{urlquote(selected_id)}&limit=1"
                )
                wo = details[0] if details else None
            except Exception as e:
                st.error(f"Failed to load job: {e}")
                wo = None

            if not wo:
                st.warning("Selected job not found.")
                if st.button("Clear selection", key="clear_sel"):
                    st.session_state.pop("selected_wo_id", None)
                    st.rerun()
                st.markdown("</div>", unsafe_allow_html=True)
            else:
                prefix = f"d_{selected_id}_"

                st.markdown(f"**WO ID:** `{wo.get('id')}`")
                st.markdown(f"**Status:** `{wo.get('status')}`")
                st.caption(f"Created: {wo.get('created_at','')}  |  Updated: {wo.get('updated_at','')}")
                st.divider()

                editable = admin_ready() and (st.session_state.get("wo_admin_pw") == ADMIN_PASSWORD)
                if not editable:
                    st.warning("View-only. Enter correct Admin Password on the left to edit + save.")

                detail_tabs = st.tabs(["Overview", "Notes", "Activity", "Files"])

                with detail_tabs[0]:
                    f_client = st.text_input("Client", value=wo.get("client_name") or "", disabled=not editable, key=prefix + "client")
                    f_store = st.text_input("Store Name", value=wo.get("store_name") or "", disabled=not editable, key=prefix + "store")

                    r1, r2 = st.columns(2)
                    f_wo = r1.text_input("WO #", value=wo.get("wo_number") or "", disabled=not editable, key=prefix + "wo")
                    f_po = r2.text_input("PO #", value=wo.get("po_number") or "", disabled=not editable, key=prefix + "po")

                    r3, r4 = st.columns(2)
                    f_city = r3.text_input("City", value=wo.get("city") or "", disabled=not editable, key=prefix + "city")
                    f_region = r4.selectbox(
                        "Region",
                        REGION_OPTIONS,
                        index=REGION_OPTIONS.index((wo.get("region") or "OTHER")) if (wo.get("region") or "OTHER") in REGION_OPTIONS else 0,
                        disabled=not editable,
                        key=prefix + "region",
                    )

                    r5, r6 = st.columns(2)
                    f_urg = r5.selectbox(
                        "Urgency",
                        URGENCY_OPTIONS,
                        index=URGENCY_OPTIONS.index((wo.get("urgency") or "24 HR")) if (wo.get("urgency") or "24 HR") in URGENCY_OPTIONS else 2,
                        disabled=not editable,
                        key=prefix + "urgency",
                    )
                    f_pri = r6.selectbox(
                        "Job Priority",
                        JOB_PRIORITY_OPTIONS,
                        index=JOB_PRIORITY_OPTIONS.index((wo.get("job_priority") or "Normal")) if (wo.get("job_priority") or "Normal") in JOB_PRIORITY_OPTIONS else 1,
                        disabled=not editable,
                        key=prefix + "priority",
                    )

                    f_sla_override = st.number_input(
                        "SLA Override (hours)",
                        min_value=0.0,
                        step=1.0,
                        value=float(wo.get("sla_override_hours") or 0.0),
                        disabled=not editable,
                        key=prefix + "sla_override_hours",
                    )

                    f_status = st.selectbox(
                        "Status",
                        STATUS_CODES,
                        index=STATUS_CODES.index((wo.get("status") or "NEW_WORK_ORDERS")) if (wo.get("status") or "NEW_WORK_ORDERS") in STATUS_CODES else 0,
                        disabled=not editable,
                        key=prefix + "status",
                    )

                    f_job_type = st.text_input("Job Type", value=wo.get("job_type") or "", disabled=not editable, key=prefix + "jobtype")
                    f_addr = st.text_input("Address", value=wo.get("site_address") or "", disabled=not editable, key=prefix + "addr")

                    f_scope = st.text_area("Description of Work", value=wo.get("scope") or "", height=180, disabled=not editable, key=prefix + "scope")

                    r7, r8 = st.columns(2)
                    f_nte = r7.number_input("NTE", min_value=0.0, step=25.0, value=float(wo.get("nte") or 0.0), disabled=not editable, key=prefix + "nte")
                    f_invoice = r8.text_input("Invoice Number", value=wo.get("invoice_number") or "", disabled=not editable, key=prefix + "invoice")

                    f_follow = st.checkbox("Follow-Up Required", value=bool(wo.get("follow_up_required") or False), disabled=not editable, key=prefix + "followup")

                    r9, r10 = st.columns(2)
                    f_materials = r9.selectbox(
                        "Materials Status",
                        MATERIALS_OPTIONS,
                        index=MATERIALS_OPTIONS.index((wo.get("materials_status") or "None")) if (wo.get("materials_status") or "None") in MATERIALS_OPTIONS else 0,
                        disabled=not editable,
                        key=prefix + "materials",
                    )
                    f_est = r10.selectbox(
                        "Estimate Status",
                        ESTIMATE_STATUS_OPTIONS,
                        index=ESTIMATE_STATUS_OPTIONS.index((wo.get("estimate_status") or "Not started")) if (wo.get("estimate_status") or "Not started") in ESTIMATE_STATUS_OPTIONS else 0,
                        disabled=not editable,
                        key=prefix + "estimate",
                    )

                    f_mat_notes = st.text_area("Material Notes", value=wo.get("material_notes") or "", height=90, disabled=not editable, key=prefix + "matnotes")

                    tech_options = [None] + techs
                    def fmt_tech(x):
                        if x is None:
                            return "(unassigned)"
                        return x.get("name", "(tech)")

                    current_assigned = wo.get("assigned_tech_id")
                    default_index = 0
                    if current_assigned:
                        for i, t in enumerate(tech_options):
                            if t and t.get("id") == current_assigned:
                                default_index = i
                                break

                    tech_choice = st.selectbox(
                        "Technician Assigned",
                        options=tech_options,
                        index=default_index,
                        format_func=fmt_tech,
                        disabled=not editable,
                        key=prefix + "tech",
                    )
                    f_assigned_id = None if tech_choice is None else tech_choice.get("id")

                    b1, b2 = st.columns(2)
                    with b1:
                        if st.button("Clear selection", key=prefix + "clear"):
                            st.session_state.pop("selected_wo_id", None)
                            st.rerun()
                    with b2:
                        if st.button("Save Changes", type="primary", disabled=not editable, key=prefix + "save"):
                            try:
                                payload = {
                                    "client_name": f_client.strip(),
                                    "store_name": f_store.strip() or None,
                                    "wo_number": f_wo.strip() or None,
                                    "po_number": f_po.strip() or None,
                                    "city": f_city.strip() or None,
                                    "region": f_region,
                                    "urgency": f_urg,
                                    "job_priority": f_pri,
                                    "status": f_status,
                                    "sla_override_hours": None if f_sla_override <= 0 else float(f_sla_override),
                                    "job_type": f_job_type.strip() or None,
                                    "site_address": f_addr.strip() or None,
                                    "scope": f_scope.strip(),
                                    "nte": float(f_nte) if f_nte and f_nte > 0 else None,
                                    "invoice_number": f_invoice.strip() or None,
                                    "follow_up_required": bool(f_follow),
                                    "materials_status": f_materials,
                                    "estimate_status": f_est,
                                    "material_notes": f_mat_notes.strip() or None,
                                    "assigned_tech_id": f_assigned_id,
                                }
                                field_labels = {
                                    "client_name": "client_name",
                                    "store_name": "store_name",
                                    "wo_number": "wo_number",
                                    "po_number": "po_number",
                                    "city": "city",
                                    "region": "region",
                                    "urgency": "urgency",
                                    "job_priority": "job_priority",
                                    "status": "status",
                                    "sla_override_hours": "sla_override_hours",
                                    "job_type": "job_type",
                                    "site_address": "site_address",
                                    "scope": "scope",
                                    "nte": "nte",
                                    "invoice_number": "invoice_number",
                                    "follow_up_required": "follow_up_required",
                                    "materials_status": "materials_status",
                                    "estimate_status": "estimate_status",
                                    "material_notes": "material_notes",
                                    "assigned_tech_id": "assigned_tech",
                                }
                                changes = []
                                for key in payload:
                                    old_val = normalize_field_value(key, wo.get(key))
                                    new_val = normalize_field_value(key, payload.get(key))
                                    if old_val != new_val:
                                        changes.append(
                                            f"{field_labels.get(key, key)}: "
                                            f"{format_note_value(key, old_val, tech_map)} → "
                                            f"{format_note_value(key, new_val, tech_map)}"
                                        )

                                sb_patch_admin("work_orders", f"id=eq.{urlquote(selected_id)}", payload)
                                if changes:
                                    try:
                                        sb_insert_admin(
                                            "job_notes",
                                            {
                                                "work_order_id": selected_id,
                                                "note_type": "system",
                                                "body": "Updated: " + "; ".join(changes),
                                            },
                                        )
                                        bump_notes_refresh()
                                    except Exception as e:
                                        st.error(f"Failed to log activity: {e}")
                                bump_jobs_refresh()
                                st.toast("Saved.")
                                st.rerun()
                            except Exception as e:
                                st.error(str(e))

                with detail_tabs[1]:
                    note_key = f"note_add_{selected_id}"
                    if st.session_state.get("reset_note_after_add"):
                        st.session_state[note_key] = ""
                        st.session_state["reset_note_after_add"] = False
                    note_body = st.text_area("Add note", key=note_key, height=110)
                    add_note = st.button("Add note", key=f"note_add_btn_{selected_id}")
                    if add_note:
                        if not admin_ready():
                            st.error("Admin not configured.")
                        elif st.session_state.get("wo_admin_pw") != ADMIN_PASSWORD:
                            st.error("Wrong admin password.")
                        elif not note_body.strip():
                            st.error("Note cannot be blank.")
                        else:
                            try:
                                sb_insert_admin(
                                    "job_notes",
                                    {
                                        "work_order_id": selected_id,
                                        "note_type": "comment",
                                        "body": note_body.strip(),
                                    },
                                )
                                st.session_state["reset_note_after_add"] = True
                                bump_notes_refresh()
                                st.toast("Note added.")
                                st.rerun()
                            except Exception as e:
                                st.error(str(e))

                    try:
                        notes = fetch_job_notes(selected_id, refresh_nonce=st.session_state["notes_refresh_nonce"])
                    except Exception as e:
                        st.error(f"Failed to load notes: {e}")
                        notes = []

                    notes = [n for n in notes if (n.get("note_type") or "").lower() != "system"]
                    if notes:
                        for note in notes:
                            note_type = note.get("note_type") or "comment"
                            created = note.get("created_at") or ""
                            st.markdown(
                                f"<div class='cc-card'>"
                                f"<div class='cc-subtle'>{created}</div>"
                                f"<div style='margin: 6px 0;'><span class='cc-pill'>{note_type}</span></div>"
                                f"<div>{note.get('body') or ''}</div>"
                                f"</div>",
                                unsafe_allow_html=True,
                            )
                    else:
                        st.caption("No notes yet.")

                with detail_tabs[2]:
                    try:
                        activity = fetch_job_notes(selected_id, refresh_nonce=st.session_state["notes_refresh_nonce"])
                    except Exception as e:
                        st.error(f"Failed to load activity: {e}")
                        activity = []

                    activity = [n for n in activity if (n.get("note_type") or "").lower() == "system"]
                    if activity:
                        for note in activity:
                            created = note.get("created_at") or ""
                            st.markdown(
                                f"<div class='cc-card'>"
                                f"<div class='cc-subtle'>{created}</div>"
                                f"<div style='margin: 6px 0;'><span class='cc-pill'>system</span></div>"
                                f"<div>{note.get('body') or ''}</div>"
                                f"</div>",
                                unsafe_allow_html=True,
                            )
                    else:
                        st.caption("No activity yet.")

                with detail_tabs[3]:
                    st.caption("Coming soon")

                st.markdown("</div>", unsafe_allow_html=True)

# =========================================================
# TAB 3: Admin (Pricing)
# =========================================================
with tabs[2]:
    st.markdown('<div class="cc-card">', unsafe_allow_html=True)
    st.subheader("Admin: Pricing (pb_items + client overrides)")

    if not admin_ready():
        st.warning("Admin mode not configured. Check ADMIN_PASSWORD and SUPABASE_SERVICE_ROLE_KEY in .env.")
        st.write({"admin_ready": admin_ready()})
        st.markdown("</div>", unsafe_allow_html=True)
        st.stop()

    pw = st.text_input("Admin password", type="password", key="admin_pw")
    if pw != ADMIN_PASSWORD:
        st.info("Enter admin password to unlock.")
        st.markdown("</div>", unsafe_allow_html=True)
        st.stop()

    st.success("Admin unlocked.")

    st.divider()
    st.markdown("## 1) Add / Edit Canonical Service (pb_items)")

    colA, colB = st.columns([1, 1])
    with colA:
        item_name = st.text_input("Service name (match engine code if you want auto use)", value="TRIP_ASSESSMENT", key="adm_item_name")
        item_type = st.selectbox("Item type", ["service", "material", "labor", "fee"], index=0, key="adm_item_type")
        unit = st.text_input("Unit", value="each", key="adm_unit")
        is_active = st.checkbox("Active", value=True, key="adm_active")
    with colB:
        base_price = st.number_input("Base price", min_value=0.0, step=1.0, value=0.0, key="adm_base")
        min_price = st.number_input("Min price", min_value=0.0, step=1.0, value=0.0, key="adm_min")
        max_price = st.number_input("Max price", min_value=0.0, step=1.0, value=0.0, key="adm_max")

    if st.button("Upsert pb_items", type="primary", key="adm_upsert_item"):
        safe = re.sub(r"[^A-Z0-9]+", "-", item_name.strip().upper()).strip("-")[:64] or "UNNAMED"
        item_code = f"SRV-{safe}"
        payload = {
            "item_code": item_code,
            "name": item_name.strip(),
            "item_type": item_type,
            "unit": unit.strip() or "each",
            "base_price": float(base_price),
            "min_price": float(min_price),
            "max_price": float(max_price),
            "is_active": bool(is_active),
        }
        try:
            sb_upsert_admin("pb_items", payload, on_conflict="item_code")
            st.toast("pb_items saved.")
            st.cache_data.clear()
        except Exception as e:
            st.error(str(e))

    st.divider()
    st.markdown("## 2) Set Client Override (pb_client_overrides)")

    items = fetch_pb_items()
    if not items:
        st.warning("No pb_items returned. Create some first or check permissions.")
    else:
        client_name = st.text_input("Client name", key="adm_client_name")
        item_choice = st.selectbox("Service", options=items, format_func=lambda x: x.get("name", ""), key="adm_item_choice")
        override_price = st.number_input("Override price (median)", min_value=0.0, step=1.0, value=0.0, key="adm_override_price")
        override_notes = st.text_area("Notes (optional)", value="jobs=0 manual override", key="adm_override_notes")
        override_active = st.checkbox("Override active", value=True, key="adm_override_active")

        if st.button("Upsert client override", key="adm_upsert_override"):
            if not client_name.strip():
                st.error("Client name required.")
            else:
                payload = {
                    "client_name": client_name.strip(),
                    "item_id": item_choice["id"],
                    "override_price": float(override_price),
                    "notes": override_notes.strip(),
                    "is_active": bool(override_active),
                }
                try:
                    sb_upsert_admin("pb_client_overrides", payload, on_conflict="client_name,item_id")
                    st.toast("Client override saved.")
                    st.cache_data.clear()
                except Exception as e:
                    st.error(str(e))

    st.divider()
    st.markdown("## 3) Quick View: Overrides for Client")

    q_client = st.text_input("Client to view overrides", key="q_client_view")
    if q_client.strip():
        try:
            rows = fetch_client_overrides(q_client.strip())
            flat = []
            for r in rows:
                flat.append({
                    "client_name": r.get("client_name"),
                    "service": (r.get("pb_items") or {}).get("name"),
                    "override_price": r.get("override_price"),
                    "notes": r.get("notes"),
                    "active": r.get("is_active"),
                })
            if flat:
                st.dataframe(pd.DataFrame(flat), use_container_width=True, hide_index=True)
            else:
                st.info("No overrides found for that client.")
        except Exception as e:
            st.error(str(e))

    st.markdown("</div>", unsafe_allow_html=True)
