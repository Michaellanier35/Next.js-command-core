import { subscribeToNewsletter } from "./procedures/subscribe-to-newsletter";

export const newsletterRouter = {
	subscribe: subscribeToNewsletter,
};
