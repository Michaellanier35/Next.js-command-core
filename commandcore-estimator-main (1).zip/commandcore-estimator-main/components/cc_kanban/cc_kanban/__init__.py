from __future__ import annotations

from pathlib import Path

import streamlit.components.v1 as components


_THIS_FILE = Path(__file__).resolve()
_PKG_DIR = _THIS_FILE.parent
_COMPONENT_ROOT = _PKG_DIR.parent
_BUILD_DIR = (_COMPONENT_ROOT / "frontend" / "build").resolve()
_INDEX_HTML = (_BUILD_DIR / "index.html").resolve()


def _safe_listdir(path: Path) -> list[str]:
    try:
        return sorted(child.name for child in path.iterdir())
    except Exception:
        return []


_BUILD_DIR_LISTING = _safe_listdir(_BUILD_DIR) if _BUILD_DIR.exists() else []
_STATIC_DIR = _BUILD_DIR / "static"
_STATIC_LISTING = _safe_listdir(_STATIC_DIR) if _STATIC_DIR.exists() else []

print(
    "cc_kanban debug:",
    f"this_file={_THIS_FILE}",
    f"pkg_dir={_PKG_DIR}",
    f"component_root={_COMPONENT_ROOT}",
    f"build_dir={_BUILD_DIR}",
    f"build_dir_exists={_BUILD_DIR.exists()}",
    f"index_html_exists={_INDEX_HTML.exists()}",
    f"build_dir_listing={_BUILD_DIR_LISTING}",
    f"static_dir_listing={_STATIC_LISTING}",
)

if not _BUILD_DIR.exists() or not _INDEX_HTML.exists():
    raise FileNotFoundError(
        "cc_kanban frontend build is missing. "
        f"build_dir={_BUILD_DIR} exists={_BUILD_DIR.exists()} "
        f"index_html={_INDEX_HTML} exists={_INDEX_HTML.exists()} "
        f"build_dir_listing={_BUILD_DIR_LISTING} "
        f"static_dir_listing={_STATIC_LISTING}. "
        "Run npm install && npm run build in components/cc_kanban/frontend."
    )

_component_func = components.declare_component(
    "components.cc_kanban.cc_kanban", path=str(_BUILD_DIR)
)


def cc_kanban(
    columns: list[dict],
    items: list[dict],
    selected_id: str | None = None,
    enable_reorder: bool = True,
    key: str | None = None,
):
    return _component_func(
        columns=columns,
        items=items,
        selectedId=selected_id,
        enableReorder=enable_reorder,
        key=key,
        default=None,
    )
