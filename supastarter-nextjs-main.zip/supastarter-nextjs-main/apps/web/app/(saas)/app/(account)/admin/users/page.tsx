import { UserList } from "@saas/admin/component/users/UserList";

export default function AdminUserPage() {
	return (
		<div>
			<UserList />
		</div>
	);
}
