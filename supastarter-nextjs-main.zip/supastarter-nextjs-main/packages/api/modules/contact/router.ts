import { submitContactForm } from "./procedures/submit-contact-form";

export const contactRouter = {
	submit: submitContactForm,
};
