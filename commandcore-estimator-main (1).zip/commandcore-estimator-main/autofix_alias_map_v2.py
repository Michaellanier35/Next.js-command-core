import pandas as pd

SRC = r"C:\CCData\estimator\service_alias_map_autofix.csv"
OUT = r"C:\CCData\estimator\service_alias_map_autofix_v2.csv"

df = pd.read_csv(SRC)
df.columns = [c.strip() for c in df.columns]

def classify(raw: str, current: str) -> str:
    s = str(raw).lower()

    # keep existing non-OTHER mappings (and IGNORE)
    if current and current != "OTHER":
        return current

    if "paint" in s and "labor" in s:
        return "LABOR_PAINT"
    if "demolition" in s:
        return "LABOR_DEMOLITION"
    if "welding" in s:
        return "LABOR_WELDING"
    if "electrical" in s:
        return "LABOR_ELECTRICAL"
    if "drywall" in s:
        return "LABOR_DRYWALL"
    if "framing" in s:
        return "LABOR_FRAMING"
    if "concrete" in s:
        return "LABOR_CONCRETE"
    if "ceiling tile" in s:
        return "LABOR_CEILING_TILE"
    if "cove base" in s:
        return "LABOR_COVE_BASE"
    if "standard labor" in s or "per hour" in s:
        return "LABOR_STANDARD_HOURLY"
    if "change order" in s:
        return "CHANGE_ORDER"
    if s.strip() == "processing":
        return "PROCESSING"
    if "water extractor" in s:
        return "WATER_EXTRACTION"
    if "awning wash" in s:
        return "AWNING_WASH"
    if "brick" in s:
        return "BRICK_INSTALLATION"
    if "lvp" in s:
        return "FLOOR_COVERING_LVP"
    if "gate replacement" in s:
        return "GATE_REPLACEMENT"
    if "reconstruction" in s:
        return "RECONSTRUCTION"

    return current or "OTHER"

df["canonical_service"] = df.apply(lambda r: classify(r["raw_item"], r["canonical_service"]), axis=1)
df.to_csv(OUT, index=False)

print("Saved:", OUT)
print("OTHER rows:", int((df["canonical_service"] == "OTHER").sum()))
