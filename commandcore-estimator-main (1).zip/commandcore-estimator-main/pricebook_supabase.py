import os
import requests
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL", "").rstrip("/")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY", "")

REST_BASE = f"{SUPABASE_URL}/rest/v1"

def _headers():
    if not SUPABASE_URL or not SUPABASE_ANON_KEY:
        raise RuntimeError("Missing SUPABASE_URL or SUPABASE_ANON_KEY in .env")
    return {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
    }

def fetch_pb_items(active_only: bool = True) -> list[dict]:
    q = "select=id,item_code,name,item_type,unit,base_price,min_price,max_price,is_active"
    url = f"{REST_BASE}/pb_items?{q}"
    if active_only:
        url += "&is_active=eq.true"
    r = requests.get(url, headers=_headers(), timeout=60)
    r.raise_for_status()
    return r.json()

def fetch_client_overrides(client_name: str) -> list[dict]:
    q = "select=id,client_name,item_id,override_price,notes,is_active"
    url = f"{REST_BASE}/pb_client_overrides?{q}&client_name=eq.{requests.utils.quote(client_name)}&is_active=eq.true"
    r = requests.get(url, headers=_headers(), timeout=60)
    r.raise_for_status()
    return r.json()

def fetch_alias_lookup() -> dict[str, str]:
    """
    Returns {alias_text_lower: item_id}
    """
    q = "select=alias,item_id"
    url = f"{REST_BASE}/pb_item_aliases?{q}"
    r = requests.get(url, headers=_headers(), timeout=60)
    r.raise_for_status()
    rows = r.json()
    return {row["alias"].strip().lower(): row["item_id"] for row in rows}
