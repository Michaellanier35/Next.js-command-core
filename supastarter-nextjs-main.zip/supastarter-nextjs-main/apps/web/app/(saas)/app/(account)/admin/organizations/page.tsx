import { OrganizationList } from "@saas/admin/component/organizations/OrganizationList";

export default function AdminOrganizationsPage() {
	return <OrganizationList />;
}
