---
title: Privacy Policy
---

This is the placeholder page for your privacy policy. Edit the `content/legal/privacy-policy.md` file to add your own content here.
