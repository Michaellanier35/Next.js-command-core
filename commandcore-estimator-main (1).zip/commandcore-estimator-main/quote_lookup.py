import argparse
import pandas as pd

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--customer", required=True)
    ap.add_argument("--service", required=True)
    ap.add_argument("--pricebook", default=r"C:\CCData\estimator\pricebook_norm.csv")
    args = ap.parse_args()

    df = pd.read_csv(args.pricebook)
    df.columns = [c.strip() for c in df.columns]

    # Normalize
    df["cust_norm"] = df["Customer full name"].astype(str).str.lower().str.strip()
    df["svc_norm"] = df["canonical_service"].astype(str).str.upper().str.strip()

    cust = args.customer.lower().strip()
    svc = args.service.upper().strip()

    # Try customer-specific first
    sub = df[(df["cust_norm"] == cust) & (df["svc_norm"] == svc)].copy()

    # Fallback to global if customer not found
    if sub.empty:
        sub = df[df["svc_norm"] == svc].copy()
        if sub.empty:
            print("No matches for service:", svc)
            return
        sub["count"] = pd.to_numeric(sub["count"], errors="coerce").fillna(0)
        best = sub.sort_values("count", ascending=False).iloc[0]
        print("Customer not found, using global best match.")
        print("Customer:", args.customer)
        print("Service:", svc)
        print("Best source row customer:", best["Customer full name"])
        print("Examples:", int(best["count"]))
        print("Median:", float(best["median_price"]))
        print("Range:", float(best["min_price"]), "-", float(best["max_price"]))
        print("Avg qty:", float(best["avg_qty"]))
        return

    sub["count"] = pd.to_numeric(sub["count"], errors="coerce").fillna(0)
    best = sub.sort_values("count", ascending=False).iloc[0]

    print("Customer:", args.customer)
    print("Service:", svc)
    print("Examples:", int(best["count"]))
    print("Median:", float(best["median_price"]))
    print("Range:", float(best["min_price"]), "-", float(best["max_price"]))
    print("Avg qty:", float(best["avg_qty"]))

if __name__ == "__main__":
    main()
