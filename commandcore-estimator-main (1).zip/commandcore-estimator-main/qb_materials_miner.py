import argparse
import csv
import re
import os
from datetime import datetime

import pandas as pd

# -----------------------------
# Filters
# -----------------------------
EXCLUDE_TEXT_PATTERNS = [
    r"\btrip\b",
    r"\blabor\b",
    r"\bassessment\b",
    r"\bbase\s*rate\b",
    r"\bservice\s*call\b",
    r"\bdispatch\b",
    r"\btravel\b",
    r"\bdiagnostic\b",
    r"\bnte\b",
]

GENERIC_ITEM_NAMES = {
    "materials",
    "material",
}

# -----------------------------
# Helpers
# -----------------------------
def norm_text(s: str) -> str:
    s = (s or "").strip().lower()
    s = re.sub(r"\s+", " ", s)
    return s


def parse_float(s: str):
    try:
        return float((s or "").replace("$", "").replace(",", "").strip())
    except Exception:
        return None


def parse_date(s: str):
    s = (s or "").strip()
    if not s:
        return None
    for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt).date()
        except Exception:
            pass
    return None


def is_excluded(text: str) -> bool:
    return any(re.search(p, text, flags=re.IGNORECASE) for p in EXCLUDE_TEXT_PATTERNS)


# -----------------------------
# Main
# -----------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--qb_sales_detail", required=True, help="Path to qb_sales_raw.csv")
    ap.add_argument("--out_dir", default=".", help="Output directory")
    ap.add_argument("--min_count", type=int, default=3, help="Minimum times item must appear")
    ap.add_argument("--min_amount", type=float, default=1.0, help="Minimum dollar amount")
    ap.add_argument("--include_generic", action="store_true", help="Include generic 'Materials' lines")
    args = ap.parse_args()

    rows = []

    with open(args.qb_sales_detail, newline="", errors="ignore") as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) < 15:
                continue

            if row[2].strip() != "Invoice":
                continue

            invoice_num = (row[3] or "").strip()
            item = (row[4] or "").strip()
            desc = (row[5] or "").strip()
            amount_raw = (row[8] or "").strip()
            customer = (row[14] or "").strip()
            date_raw = (row[1] or "").strip()

            if not invoice_num:
                continue

            amount = parse_float(amount_raw)
            if amount is None or amount < args.min_amount:
                continue

            text = norm_text(f"{item} {desc}")
            if is_excluded(text):
                continue

            item_norm = norm_text(item)
            if not item_norm:
                continue

            if (item_norm in GENERIC_ITEM_NAMES) and (not args.include_generic):
                continue

            rows.append(
                {
                    "invoice_num": invoice_num,
                    "date": date_raw,
                    "date_parsed": parse_date(date_raw),
                    "customer": customer,
                    "item": item,
                    "item_norm": item_norm,
                    "desc": desc,
                    "amount": amount,
                }
            )

    if not rows:
        print("No rows found after filtering.")
        return

    df = pd.DataFrame(rows)

    grp = df.groupby("item_norm", dropna=False)

    catalog = grp.agg(
        example_name=("item", lambda s: s.value_counts().index[0]),
        count=("item_norm", "size"),
        customers_count=("customer", "nunique"),
        amount_min=("amount", "min"),
        amount_median=("amount", "median"),
        amount_max=("amount", "max"),
        first_seen=("date_parsed", "min"),
        last_seen=("date_parsed", "max"),
    ).reset_index()

    catalog = catalog[catalog["count"] >= args.min_count]
    catalog = catalog.sort_values(["count", "customers_count"], ascending=[False, False])

    # Output paths (SAFE)
    out_dir = os.path.abspath(args.out_dir)
    os.makedirs(out_dir, exist_ok=True)

    catalog_path = os.path.join(out_dir, "materials_catalog.csv")
    examples_path = os.path.join(out_dir, "materials_examples.csv")

    catalog.to_csv(catalog_path, index=False)

    # Small examples file for inspection
    df.sort_values(["item_norm", "amount"], ascending=[True, False]).head(300).to_csv(
        examples_path, index=False
    )

    print(f"Wrote: {catalog_path}")
    print(f"Wrote: {examples_path}")
    print(f"Catalog rows: {len(catalog)}")


if __name__ == "__main__":
    main()
