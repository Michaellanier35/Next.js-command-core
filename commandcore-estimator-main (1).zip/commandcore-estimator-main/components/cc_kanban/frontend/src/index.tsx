import React from "react";
import ReactDOM from "react-dom/client";
import { Streamlit, withStreamlitConnection, ComponentProps } from "streamlit-component-lib";

import Kanban from "./kanban";
import "./styles.css";

const KanbanWrapper = ({ args }: ComponentProps) => {
  const columns = (args?.columns as KanbanColumn[]) ?? [];
  const items = (args?.items as KanbanItem[]) ?? [];
  const selectedId = (args?.selectedId as string | null) ?? null;
  const enableReorder = Boolean(args?.enableReorder);

  return (
    <Kanban
      columns={columns}
      items={items}
      selectedId={selectedId}
      enableReorder={enableReorder}
    />
  );
};

export type KanbanColumn = {
  id: string;
  title: string;
  count: number;
};

export type KanbanItem = {
  id: string;
  columnId: string;
  title: string;
  subtitle: string;
  badges: string[];
  meta?: Record<string, unknown>;
};

const ConnectedKanban = withStreamlitConnection(KanbanWrapper);

const rootElement = document.getElementById("root");
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(<ConnectedKanban />);
  Streamlit.setFrameHeight();
}
